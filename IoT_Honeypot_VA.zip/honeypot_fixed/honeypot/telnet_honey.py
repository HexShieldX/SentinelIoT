"""
honeypot/telnet_honey.py
========================
Fake Telnet service that presents a convincing IoT router/device banner,
accepts any credentials, records all commands typed by the attacker.
"""
import asyncio
import logging
from datetime import datetime

from config.settings import HOST, TELNET_PORT, FAKE_DEVICE, HONEY_CREDENTIALS
from honeypot.core import bus, insert_credential, insert_session

logger = logging.getLogger("honeypot.telnet")

BANNER = (
    "\r\n"
    "############################################\r\n"
    f"  {FAKE_DEVICE['manufacturer']} — {FAKE_DEVICE['model']}\r\n"
    f"  Firmware {FAKE_DEVICE['firmware']}  |  S/N {FAKE_DEVICE['serial']}\r\n"
    "  Unauthorized access is strictly prohibited.\r\n"
    "############################################\r\n\r\n"
)

FAKE_RESPONSES = {
    "ls":      "bin  dev  etc  home  lib  proc  root  sys  tmp  usr  var\r\n",
    "ls -la":  "total 64\r\ndrwxr-xr-x  2 root root 4096 Jan 1 00:00 .\r\n"
               "drwxr-xr-x 18 root root 4096 Jan 1 00:00 ..\r\n",
    "id":      "uid=0(root) gid=0(root) groups=0(root)\r\n",
    "uname -a":"Linux smarthome-gw 4.14.0 #1 SMP Wed Jan 1 00:00:00 UTC 2020 mips GNU/Linux\r\n",
    "cat /etc/passwd": "root:x:0:0:root:/root:/bin/sh\nadmin:x:1000:1000::/home/admin:/bin/sh\r\n",
    "whoami":  "root\r\n",
    "pwd":     "/root\r\n",
    "ps":      "  PID TTY          TIME CMD\r\n    1 ?        00:00:01 init\r\n   42 ?        00:00:00 telnetd\r\n",
    "ifconfig":"eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\r\n"
               "        inet 192.168.1.1  netmask 255.255.255.0  broadcast 192.168.1.255\r\n",
    "cat /proc/cpuinfo": "system type\t\t: SmartHome SH-3000\r\nprocessor\t\t: 0\r\ncpu model\t\t: MIPS 24Kc\r\n",
}


class TelnetSession:
    IAC  = bytes([255])
    DONT = bytes([254])
    DO   = bytes([253])
    WONT = bytes([252])
    WILL = bytes([251])
    ECHO = bytes([1])
    SGA  = bytes([3])

    def __init__(self, reader, writer):
        self.reader   = reader
        self.writer   = writer
        self.peer     = writer.get_extra_info("peername", ("unknown", 0))
        self.src_ip   = self.peer[0]
        self.src_port = self.peer[1]
        self.username = ""
        self.password = ""
        self.commands = []
        self.start_ts = datetime.utcnow()

    def _emit(self, action: str, payload: str = ""):
        bus.publish({
            "protocol":  "TELNET",
            "src_ip":    self.src_ip,
            "src_port":  self.src_port,
            "action":    action,
            "payload":   payload,
            "timestamp": datetime.utcnow().isoformat(),
        })

    async def _send(self, text: str):
        self.writer.write(text.encode("utf-8", errors="replace"))
        await self.writer.drain()

    async def _readline(self, echo: bool = True, mask: bool = False) -> str:
        """Read a line, handling backspace and basic Telnet control sequences."""
        buf = []
        while True:
            try:
                ch = await asyncio.wait_for(self.reader.read(1), timeout=60)
            except asyncio.TimeoutError:
                raise ConnectionResetError("timeout")
            if not ch:
                raise ConnectionResetError("closed")
            b = ch[0]
            if b == 255:  # IAC
                await self.reader.read(2)  # skip option negotiation
                continue
            if b in (13, 10):  # CR or LF
                await self._send("\r\n")
                return "".join(buf)
            if b == 127 or b == 8:  # backspace
                if buf:
                    buf.pop()
                    await self._send("\b \b")
                continue
            c = chr(b)
            buf.append(c)
            if echo:
                await self._send("*" if mask else c)

    async def handle(self):
        logger.info("Telnet connection from %s:%s", self.src_ip, self.src_port)
        self._emit("CONNECT", "new telnet connection")
        try:
            # Negotiate: WILL ECHO, WILL SGA
            self.writer.write(self.IAC + self.WILL + self.ECHO)
            self.writer.write(self.IAC + self.WILL + self.SGA)
            await self.writer.drain()

            await self._send(BANNER)
            await self._send("Login: ")
            self.username = await self._readline()
            await self._send("Password: ")
            self.password = await self._readline(mask=True)

            insert_credential({
                "protocol": "TELNET",
                "src_ip":   self.src_ip,
                "username": self.username,
                "password": self.password,
            })
            self._emit("AUTH_ATTEMPT", f"user={self.username} pass={self.password}")

            await self._send("\r\nLogin successful.\r\n\r\n")
            await self._send(f"{FAKE_DEVICE['model']}:~# ")

            while True:
                try:
                    cmd = await asyncio.wait_for(self._readline(), timeout=120)
                except asyncio.TimeoutError:
                    await self._send("\r\nSession timed out.\r\n")
                    break

                if not cmd.strip():
                    await self._send(f"{FAKE_DEVICE['model']}:~# ")
                    continue

                self.commands.append(cmd)
                self._emit("COMMAND", cmd)

                if cmd.strip().lower() in ("exit", "logout", "quit"):
                    await self._send("logout\r\n")
                    break

                response = FAKE_RESPONSES.get(cmd.strip(), f"-sh: {cmd.strip()}: command not found\r\n")
                await self._send(response)
                await self._send(f"{FAKE_DEVICE['model']}:~# ")

        except (ConnectionResetError, asyncio.IncompleteReadError, BrokenPipeError):
            pass
        except Exception as e:
            logger.debug("Telnet session error %s — %s", self.src_ip, e)
        finally:
            duration = (datetime.utcnow() - self.start_ts).total_seconds()
            insert_session({
                "protocol":  "TELNET",
                "src_ip":    self.src_ip,
                "duration":  duration,
                "commands":  self.commands,
            })
            self._emit("DISCONNECT", f"commands={len(self.commands)} duration={duration:.1f}s")
            try:
                self.writer.close()
            except Exception:
                pass


async def _client_connected(reader, writer):
    session = TelnetSession(reader, writer)
    await session.handle()


async def run_telnet():
    server = await asyncio.start_server(_client_connected, HOST, TELNET_PORT)
    logger.info("Telnet honeypot listening on %s:%s", HOST, TELNET_PORT)
    async with server:
        await server.serve_forever()


def start():
    loop = asyncio.new_event_loop()
    loop.run_until_complete(run_telnet())
