"""
honeypot/coap_honey.py
======================
CoAP (Constrained Application Protocol) honeypot over UDP.
Implements RFC 7252 — handles GET / PUT / POST / DELETE on
fake IoT resource paths and logs all probes.
"""
import asyncio
import struct
import logging
import json
import random
from datetime import datetime

from config.settings import HOST, COAP_PORT, FAKE_DEVICE
from honeypot.core import bus

logger = logging.getLogger("honeypot.coap")

# ── CoAP constants ────────────────────────────────────────────────────────────
VERSION      = 1
TYPE_CON     = 0  # Confirmable
TYPE_NON     = 1  # Non-confirmable
TYPE_ACK     = 2  # Acknowledgement
TYPE_RST     = 3  # Reset

CODE_GET     = 0x01
CODE_POST    = 0x02
CODE_PUT     = 0x03
CODE_DELETE  = 0x04

CODE_CONTENT       = 0x45   # 2.05
CODE_CHANGED       = 0x44   # 2.04
CODE_DELETED       = 0x42   # 2.02
CODE_NOT_FOUND     = 0x84   # 4.04
CODE_METHOD_NA     = 0x85   # 4.05

CONTENT_TEXT = 0
CONTENT_JSON = 50

# ── Fake resource store ───────────────────────────────────────────────────────
_RESOURCES = {
    "/.well-known/core":   '</sensors>;ct=40,</actuators>;ct=40,</config>;ct=50',
    "/sensors/temp":       "23.5",
    "/sensors/humidity":   "61.2",
    "/sensors/motion":     "0",
    "/sensors/door":       "closed",
    "/actuators/relay1":   "off",
    "/actuators/relay2":   "on",
    "/config":             json.dumps({"fw": FAKE_DEVICE["firmware"],
                                       "model": FAKE_DEVICE["model"]}),
    "/status":             json.dumps({"uptime": 1234567, "heap": 48200}),
}


def _parse_coap(data: bytes):
    """Parse CoAP header. Returns (ver, msg_type, code, msg_id, token, options, payload, path)."""
    if len(data) < 4:
        return None
    byte0  = data[0]
    ver    = (byte0 >> 6) & 0x03
    mtype  = (byte0 >> 4) & 0x03
    tkl    = byte0 & 0x0F
    code   = data[1]
    msg_id = struct.unpack("!H", data[2:4])[0]
    token  = data[4:4 + tkl]
    pos    = 4 + tkl

    options = {}
    opt_num = 0
    path_parts = []

    while pos < len(data):
        if data[pos] == 0xFF:  # payload marker
            pos += 1
            break
        delta  = (data[pos] >> 4) & 0x0F
        length = data[pos] & 0x0F
        pos += 1

        if delta == 13:
            delta = data[pos] + 13; pos += 1
        elif delta == 14:
            delta = struct.unpack("!H", data[pos:pos+2])[0] + 269; pos += 2

        if length == 13:
            length = data[pos] + 13; pos += 1
        elif length == 14:
            length = struct.unpack("!H", data[pos:pos+2])[0] + 269; pos += 2

        opt_num += delta
        opt_val = data[pos:pos + length]
        pos += length

        if opt_num == 11:  # Uri-Path
            path_parts.append(opt_val.decode("utf-8", errors="replace"))
        options.setdefault(opt_num, []).append(opt_val)

    path = "/" + "/".join(path_parts) if path_parts else "/"
    payload = data[pos:] if pos < len(data) else b""
    return ver, mtype, code, msg_id, token, options, payload, path


def _build_coap(mtype: int, code: int, msg_id: int, token: bytes,
                payload: bytes = b"", content_format: int = None) -> bytes:
    tkl = len(token)
    header = bytes([(VERSION << 6) | (mtype << 4) | tkl, code]) + struct.pack("!H", msg_id)
    opts = b""
    if content_format is not None:
        # Option 12 = Content-Format
        cf_val = struct.pack("!H", content_format) if content_format > 255 else bytes([content_format])
        opts += bytes([(12 << 4) | len(cf_val)]) + cf_val
    if payload:
        return header + token + opts + bytes([0xFF]) + payload
    return header + token + opts


class CoAPProtocol(asyncio.DatagramProtocol):
    def __init__(self):
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data: bytes, addr):
        src_ip, src_port = addr
        parsed = _parse_coap(data)
        if not parsed:
            return
        ver, mtype, code, msg_id, token, options, payload, path = parsed

        method_map = {CODE_GET: "GET", CODE_POST: "POST",
                      CODE_PUT: "PUT", CODE_DELETE: "DELETE"}
        method = method_map.get(code, f"0x{code:02X}")

        bus.publish({
            "protocol":  "COAP",
            "src_ip":    src_ip,
            "src_port":  src_port,
            "action":    f"{method} {path}",
            "payload":   payload.decode("utf-8", errors="replace")[:200],
            "raw":       {"method": method, "path": path, "msg_id": msg_id,
                          "type": mtype, "payload_len": len(payload)},
            "timestamp": datetime.utcnow().isoformat(),
        })

        response = self._handle(mtype, code, msg_id, token, path, payload, method)
        if response and self.transport:
            self.transport.sendto(response, addr)

    def _handle(self, mtype, code, msg_id, token, path, payload, method):
        resp_type = TYPE_ACK if mtype == TYPE_CON else TYPE_NON

        if code == CODE_GET:
            if path in _RESOURCES:
                body = _RESOURCES[path].encode()
                cf = CONTENT_JSON if path in ("/config", "/status", "/.well-known/core") else CONTENT_TEXT
                return _build_coap(resp_type, CODE_CONTENT, msg_id, token, body, cf)
            return _build_coap(resp_type, CODE_NOT_FOUND, msg_id, token)

        elif code == CODE_PUT:
            if path in _RESOURCES:
                val = payload.decode("utf-8", errors="replace")
                _RESOURCES[path] = val
                logger.warning("CoAP PUT %s = %r from %s", path, val[:80],
                               self.transport.get_extra_info("peername"))
                return _build_coap(resp_type, CODE_CHANGED, msg_id, token)
            return _build_coap(resp_type, CODE_NOT_FOUND, msg_id, token)

        elif code == CODE_POST:
            _RESOURCES[path] = payload.decode("utf-8", errors="replace")
            return _build_coap(resp_type, CODE_CHANGED, msg_id, token)

        elif code == CODE_DELETE:
            return _build_coap(resp_type, CODE_DELETED, msg_id, token)

        return _build_coap(resp_type, CODE_METHOD_NA, msg_id, token)

    def error_received(self, exc):
        logger.debug("CoAP error: %s", exc)


async def run_coap():
    loop = asyncio.get_event_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        CoAPProtocol, local_addr=(HOST, COAP_PORT)
    )
    logger.info("CoAP honeypot listening on %s:%s (UDP)", HOST, COAP_PORT)
    try:
        await asyncio.sleep(float("inf"))
    finally:
        transport.close()


def start():
    loop = asyncio.new_event_loop()
    loop.run_until_complete(run_coap())
