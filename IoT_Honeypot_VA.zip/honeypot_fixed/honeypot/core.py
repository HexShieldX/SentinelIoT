"""
honeypot/core.py
================
Central event bus, SQLite persistence, GeoIP enrichment,
structured logging, and shared utilities.
"""
import sqlite3
import logging
import logging.handlers
import json
import socket
import threading
import time
import os
from datetime import datetime
from queue import Queue, Empty
from typing import Optional, Dict, Any

# Optional GeoIP — gracefully degraded if maxminddb not installed
try:
    import maxminddb
    _GEOIP_AVAILABLE = True
except ImportError:
    _GEOIP_AVAILABLE = False

from config.settings import DB_PATH, LOG_LEVEL, LOG_FILE

# ── Logger setup ─────────────────────────────────────────────────────────────

def setup_logging() -> logging.Logger:
    os.makedirs(os.path.dirname(LOG_FILE) if os.path.dirname(LOG_FILE) else ".", exist_ok=True)
    logger = logging.getLogger("honeypot")
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    # Console
    ch = logging.StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    # Rotating file
    fh = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=10_000_000, backupCount=5)
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger

logger = setup_logging()


# ── Database ─────────────────────────────────────────────────────────────────

_DB_LOCK = threading.Lock()

def get_db() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH) if os.path.dirname(DB_PATH) else ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with _DB_LOCK:
        conn = get_db()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS events (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp    TEXT    NOT NULL,
                protocol     TEXT    NOT NULL,
                src_ip       TEXT,
                src_port     INTEGER,
                action       TEXT,
                payload      TEXT,
                country      TEXT,
                city         TEXT,
                latitude     REAL,
                longitude    REAL,
                is_anomaly   INTEGER DEFAULT 0,
                anomaly_score REAL   DEFAULT 0.0,
                raw          TEXT
            );

            CREATE TABLE IF NOT EXISTS credentials (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT    NOT NULL,
                protocol  TEXT,
                src_ip    TEXT,
                username  TEXT,
                password  TEXT
            );

            CREATE TABLE IF NOT EXISTS sessions (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp  TEXT NOT NULL,
                protocol   TEXT,
                src_ip     TEXT,
                duration   REAL,
                commands   TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_events_ts       ON events(timestamp);
            CREATE INDEX IF NOT EXISTS idx_events_proto    ON events(protocol);
            CREATE INDEX IF NOT EXISTS idx_events_src_ip   ON events(src_ip);
        """)
        conn.commit()
        conn.close()
    logger.info("Database initialised at %s", DB_PATH)


def insert_event(event: Dict[str, Any]) -> int:
    with _DB_LOCK:
        conn = get_db()
        cur = conn.execute("""
            INSERT INTO events
                (timestamp, protocol, src_ip, src_port, action, payload,
                 country, city, latitude, longitude, is_anomaly, anomaly_score, raw)
            VALUES
                (:timestamp, :protocol, :src_ip, :src_port, :action, :payload,
                 :country, :city, :latitude, :longitude, :is_anomaly, :anomaly_score, :raw)
        """, {
            "timestamp":     event.get("timestamp", datetime.utcnow().isoformat()),
            "protocol":      event.get("protocol",  "UNKNOWN"),
            "src_ip":        event.get("src_ip",    ""),
            "src_port":      event.get("src_port",  0),
            "action":        event.get("action",    ""),
            "payload":       event.get("payload",   ""),
            "country":       event.get("country",   ""),
            "city":          event.get("city",      ""),
            "latitude":      event.get("latitude",  0.0),
            "longitude":     event.get("longitude", 0.0),
            "is_anomaly":    int(event.get("is_anomaly", False)),
            "anomaly_score": float(event.get("anomaly_score", 0.0)),
            "raw":           json.dumps(event.get("raw", {})),
        })
        conn.commit()
        row_id = cur.lastrowid
        conn.close()
    event["id"] = row_id  # FIX: allow anomaly detector to UPDATE this row
    return row_id


def insert_credential(data: Dict[str, Any]):
    with _DB_LOCK:
        conn = get_db()
        conn.execute("""
            INSERT INTO credentials (timestamp, protocol, src_ip, username, password)
            VALUES (:timestamp, :protocol, :src_ip, :username, :password)
        """, {
            "timestamp": data.get("timestamp", datetime.utcnow().isoformat()),
            "protocol":  data.get("protocol", ""),
            "src_ip":    data.get("src_ip",   ""),
            "username":  data.get("username", ""),
            "password":  data.get("password", ""),
        })
        conn.commit()
        conn.close()


def insert_session(data: Dict[str, Any]):
    with _DB_LOCK:
        conn = get_db()
        conn.execute("""
            INSERT INTO sessions (timestamp, protocol, src_ip, duration, commands)
            VALUES (:timestamp, :protocol, :src_ip, :duration, :commands)
        """, {
            "timestamp": data.get("timestamp", datetime.utcnow().isoformat()),
            "protocol":  data.get("protocol", ""),
            "src_ip":    data.get("src_ip",   ""),
            "duration":  data.get("duration", 0.0),
            "commands":  json.dumps(data.get("commands", [])),
        })
        conn.commit()
        conn.close()


def query_events(limit: int = 200, protocol: str = None,
                 anomaly_only: bool = False) -> list:
    with _DB_LOCK:
        conn = get_db()
        q = "SELECT * FROM events WHERE 1=1"
        params: list = []
        if protocol:
            q += " AND protocol = ?"
            params.append(protocol)
        if anomaly_only:
            q += " AND is_anomaly = 1"
        q += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        rows = [dict(r) for r in conn.execute(q, params).fetchall()]
        conn.close()
    return rows


def get_stats() -> Dict[str, Any]:
    with _DB_LOCK:
        conn = get_db()
        total        = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        anomalies    = conn.execute("SELECT COUNT(*) FROM events WHERE is_anomaly=1").fetchone()[0]
        unique_ips   = conn.execute("SELECT COUNT(DISTINCT src_ip) FROM events").fetchone()[0]
        cred_count   = conn.execute("SELECT COUNT(*) FROM credentials").fetchone()[0]
        by_proto     = {r[0]: r[1] for r in conn.execute(
            "SELECT protocol, COUNT(*) FROM events GROUP BY protocol").fetchall()}
        top_ips      = [dict(r) for r in conn.execute(
            "SELECT src_ip, COUNT(*) as cnt FROM events GROUP BY src_ip ORDER BY cnt DESC LIMIT 10"
        ).fetchall()]
        top_countries = [dict(r) for r in conn.execute(
            "SELECT country, COUNT(*) as cnt FROM events WHERE country != '' GROUP BY country ORDER BY cnt DESC LIMIT 10"
        ).fetchall()]
        recent       = [dict(r) for r in conn.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT 20").fetchall()]
        conn.close()
    return {
        "total_events":   total,
        "anomalies":      anomalies,
        "unique_ips":     unique_ips,
        "credentials":    cred_count,
        "by_protocol":    by_proto,
        "top_ips":        top_ips,
        "top_countries":  top_countries,
        "recent_events":  recent,
    }


# ── GeoIP enrichment ─────────────────────────────────────────────────────────

_geoip_db: Optional[Any] = None

def load_geoip(path: str = "GeoLite2-City.mmdb"):
    global _geoip_db
    if _GEOIP_AVAILABLE and os.path.exists(path):
        _geoip_db = maxminddb.open_database(path)
        logger.info("GeoIP database loaded from %s", path)
    else:
        logger.warning("GeoIP database not found — location data will be empty. "
                       "Download GeoLite2-City.mmdb from MaxMind and place in project root.")

def geoip_lookup(ip: str) -> Dict[str, Any]:
    if _geoip_db is None:
        return {}
    try:
        record = _geoip_db.get(ip)
        if not record:
            return {}
        return {
            "country":   record.get("country", {}).get("names", {}).get("en", ""),
            "city":      record.get("city",    {}).get("names", {}).get("en", ""),
            "latitude":  record.get("location", {}).get("latitude",  0.0),
            "longitude": record.get("location", {}).get("longitude", 0.0),
        }
    except Exception:
        return {}


# ── Global event bus ─────────────────────────────────────────────────────────

class EventBus:
    """Thread-safe pub/sub bus. Subscribers receive events asynchronously."""

    def __init__(self):
        self._subscribers: list = []
        self._queue: Queue = Queue(maxsize=10_000)
        self._worker = threading.Thread(target=self._dispatch, daemon=True)
        self._worker.start()

    def publish(self, event: Dict[str, Any]):
        # Enrich with GeoIP
        geo = geoip_lookup(event.get("src_ip", ""))
        event.update(geo)
        # Timestamp
        if "timestamp" not in event:
            event["timestamp"] = datetime.utcnow().isoformat()
        # Score anomaly BEFORE insert so DB row has correct is_anomaly value
        try:
            from ml.anomaly import detector
            detector.score(event)
        except Exception:
            pass
        # Persist
        try:
            insert_event(event)
        except Exception as e:
            logger.error("DB insert failed: %s", e)
        # Queue for subscribers (dashboard SSE, etc.)
        try:
            self._queue.put_nowait(event)
        except Exception:
            pass  # drop if full
        logger.info("[%s] %s:%s — %s — %s",
                    event.get("protocol"), event.get("src_ip"),
                    event.get("src_port"), event.get("action"),
                    event.get("payload", "")[:80])

    def subscribe(self, callback):
        self._subscribers.append(callback)

    def _dispatch(self):
        while True:
            try:
                event = self._queue.get(timeout=1)
                for cb in self._subscribers:
                    try:
                        cb(event)
                    except Exception as e:
                        logger.error("Subscriber error: %s", e)
            except Empty:
                continue


# Singleton
bus = EventBus()
