"""
honeypot/ssh_honey.py
=====================
SSH honeypot built on paramiko. Presents a realistic SSH server,
logs all auth attempts (including public keys), and drops attackers
into a fake interactive shell to capture post-exploitation commands.
"""
import socket
import threading
import logging
import os
import time
from datetime import datetime

import paramiko

from config.settings import HOST, SSH_PORT, FAKE_DEVICE
from honeypot.core import bus, insert_credential, insert_session
from mitigation.mitigations import ssh_blocker

logger = logging.getLogger("honeypot.ssh")

# ── Generate (or load) host RSA key ─────────────────────────────────────────
_KEY_PATH = "config/ssh_host_rsa_key"

def _get_host_key() -> paramiko.RSAKey:
    if os.path.exists(_KEY_PATH):
        return paramiko.RSAKey(filename=_KEY_PATH)
    logger.info("Generating SSH host key …")
    key = paramiko.RSAKey.generate(2048)
    os.makedirs(os.path.dirname(_KEY_PATH), exist_ok=True)
    key.write_private_key_file(_KEY_PATH)
    return key

HOST_KEY = _get_host_key()

FAKE_SHELL_RESPONSES = {
    "ls":          "bin  dev  etc  home  lib  proc  root  sys  tmp  usr  var",
    "id":          "uid=0(root) gid=0(root) groups=0(root)",
    "uname -a":    f"Linux {FAKE_DEVICE['model'].lower().replace(' ','-')} 4.19.0 #1 SMP mips GNU/Linux",
    "whoami":      "root",
    "pwd":         "/root",
    "cat /etc/shadow": "root:$6$fakehash$abc123:18000:0:99999:7:::",
    "wget":        "wget: missing URL",
    "curl":        "curl: try 'curl --help' for more information",
    "ps aux":      "  PID USER  %CPU %MEM COMMAND\n    1 root   0.0  0.1 /sbin/init\n   42 root   0.0  0.0 sshd",
}

MOTD = (
    f"\r\nWelcome to {FAKE_DEVICE['manufacturer']} {FAKE_DEVICE['model']}\r\n"
    f"Firmware: {FAKE_DEVICE['firmware']}\r\n"
    "Last login: Mon Jan  1 00:00:00 2024 from 192.168.1.10\r\n\r\n"
)


class HoneyInterface(paramiko.ServerInterface):
    def __init__(self, src_ip: str, src_port: int):
        self.src_ip    = src_ip
        self.src_port  = src_port
        self.username  = ""
        self.password  = ""
        self.event     = threading.Event()

    def check_channel_request(self, kind, chanid):
        if kind in ("session",):
            return paramiko.OPEN_SUCCEEDED
        return paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_auth_password(self, username: str, password: str) -> int:
        self.username = username
        self.password = password

        # MITIGATION 1: Brute-Force Rate Limiter
        allowed, reason = ssh_blocker.record_attempt(self.src_ip)
        if not allowed:
            time.sleep(ssh_blocker.HONEYPOT_SLOW_DOWN)
            bus.publish({
                "protocol":  "SSH",
                "src_ip":    self.src_ip,
                "src_port":  self.src_port,
                "action":    "AUTH_BLOCKED",
                "payload":   f"[MITIGATED] {reason} user={username}",
                "timestamp": datetime.utcnow().isoformat(),
            })
            return paramiko.AUTH_FAILED
        # end mitigation

        bus.publish({
            "protocol":  "SSH",
            "src_ip":    self.src_ip,
            "src_port":  self.src_port,
            "action":    "AUTH_PASSWORD",
            "payload":   f"user={username} pass={password}",
            "timestamp": datetime.utcnow().isoformat(),
        })
        insert_credential({
            "protocol": "SSH",
            "src_ip":   self.src_ip,
            "username": username,
            "password": password,
        })
        return paramiko.AUTH_SUCCESSFUL  # honeypot still accepts for logging

    def check_auth_publickey(self, username: str, key: paramiko.PKey) -> int:
        fp = key.get_fingerprint().hex()
        bus.publish({
            "protocol":  "SSH",
            "src_ip":    self.src_ip,
            "src_port":  self.src_port,
            "action":    "AUTH_PUBKEY",
            "payload":   f"user={username} fingerprint={fp}",
            "timestamp": datetime.utcnow().isoformat(),
        })
        return paramiko.AUTH_SUCCESSFUL

    def get_allowed_auths(self, username: str) -> str:
        return "password,publickey"

    def check_channel_pty_request(self, channel, term, width, height, pixelwidth, pixelheight, modes):
        return True

    def check_channel_shell_request(self, channel):
        self.event.set()
        return True

    def check_channel_exec_request(self, channel, command: bytes):
        self.event.set()
        return True


def _handle_client(client_sock: socket.socket, addr):
    src_ip, src_port = addr
    commands = []
    start_ts = datetime.utcnow()

    bus.publish({
        "protocol":  "SSH",
        "src_ip":    src_ip,
        "src_port":  src_port,
        "action":    "CONNECT",
        "payload":   "new SSH connection",
        "timestamp": start_ts.isoformat(),
    })

    try:
        transport = paramiko.Transport(client_sock)
        transport.add_server_key(HOST_KEY)
        transport.local_version = f"SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6"

        server = HoneyInterface(src_ip, src_port)
        try:
            transport.start_server(server=server)
        except paramiko.SSHException:
            return

        chan = transport.accept(20)
        if chan is None:
            return

        server.event.wait(10)
        chan.send(MOTD.encode())
        chan.send(f"root@{FAKE_DEVICE['model'].lower().replace(' ','-')}:~# ".encode())

        buf = ""
        chan.settimeout(120)
        while True:
            try:
                data = chan.recv(1024)
            except socket.timeout:
                chan.send(b"\r\nSession timed out.\r\n")
                break
            if not data:
                break

            for b in data:
                ch = chr(b)
                if ch in ("\r", "\n"):
                    chan.send(b"\r\n")
                    cmd = buf.strip()
                    buf = ""
                    if not cmd:
                        pass
                    elif cmd.lower() in ("exit", "logout", "quit"):
                        chan.send(b"logout\r\n")
                        commands.append(cmd)
                        bus.publish({
                            "protocol": "SSH", "src_ip": src_ip,
                            "src_port": src_port, "action": "COMMAND",
                            "payload": cmd, "timestamp": datetime.utcnow().isoformat(),
                        })
                        goto_end = True
                        break
                    else:
                        commands.append(cmd)
                        bus.publish({
                            "protocol": "SSH", "src_ip": src_ip,
                            "src_port": src_port, "action": "COMMAND",
                            "payload": cmd, "timestamp": datetime.utcnow().isoformat(),
                        })
                        resp = FAKE_SHELL_RESPONSES.get(cmd, f"-bash: {cmd}: command not found")
                        chan.send((resp + "\r\n").encode())
                    chan.send(f"root@{FAKE_DEVICE['model'].lower().replace(' ','-')}:~# ".encode())
                elif b == 127 or b == 8:
                    if buf:
                        buf = buf[:-1]
                        chan.send(b"\b \b")
                else:
                    buf += ch
                    chan.send(ch.encode())
            else:
                continue
            break

    except Exception as e:
        logger.debug("SSH session error %s — %s", src_ip, e)
    finally:
        duration = (datetime.utcnow() - start_ts).total_seconds()
        insert_session({
            "protocol": "SSH", "src_ip": src_ip,
            "duration": duration, "commands": commands,
        })
        bus.publish({
            "protocol": "SSH", "src_ip": src_ip, "src_port": src_port,
            "action": "DISCONNECT",
            "payload": f"commands={len(commands)} duration={duration:.1f}s",
            "timestamp": datetime.utcnow().isoformat(),
        })
        try:
            client_sock.close()
        except Exception:
            pass


def start():
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind((HOST, SSH_PORT))
    sock.listen(50)
    logger.info("SSH honeypot listening on %s:%s", HOST, SSH_PORT)
    while True:
        try:
            client, addr = sock.accept()
            t = threading.Thread(target=_handle_client, args=(client, addr), daemon=True)
            t.start()
        except Exception as e:
            logger.error("SSH accept error: %s", e)
