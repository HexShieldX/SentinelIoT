"""
honeypot/mqtt_honey.py
======================
Fake MQTT broker that accepts any connection, logs CONNECT / PUBLISH /
SUBSCRIBE packets, and responds with valid MQTT ACKs to keep attackers engaged.
Implements a minimal MQTT 3.1.1 parser (no external broker needed).
"""
import asyncio
import struct
import logging
import json
from datetime import datetime
from typing import Optional

from config.settings import HOST, MQTT_PORT, MQTT_TOPICS
from honeypot.core import bus
from mitigation.mitigations import mqtt_enforcer, CONNACK_ACCEPTED, CONNACK_REFUSED_BAD_CREDENTIALS

logger = logging.getLogger("honeypot.mqtt")

# ── MQTT packet type constants ───────────────────────────────────────────────
CONNECT     = 0x10
CONNACK     = 0x20
PUBLISH     = 0x30
PUBACK      = 0x40
SUBSCRIBE   = 0x82
SUBACK      = 0x90
UNSUBSCRIBE = 0xA2
UNSUBACK    = 0xB0
PINGREQ     = 0xC0
PINGRESP    = 0xD0
DISCONNECT  = 0xE0


def encode_remaining_length(length: int) -> bytes:
    result = b""
    while True:
        byte = length % 128
        length //= 128
        if length > 0:
            byte |= 0x80
        result += bytes([byte])
        if length == 0:
            break
    return result


def decode_remaining_length(data: bytes, offset: int):
    multiplier = 1
    value = 0
    while True:
        byte = data[offset]
        offset += 1
        value += (byte & 127) * multiplier
        multiplier *= 128
        if not (byte & 128):
            break
    return value, offset


def read_utf8_string(data: bytes, offset: int):
    length = struct.unpack_from("!H", data, offset)[0]
    offset += 2
    s = data[offset:offset + length].decode("utf-8", errors="replace")
    return s, offset + length


class MQTTSession:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.reader  = reader
        self.writer  = writer
        self.peer    = writer.get_extra_info("peername", ("unknown", 0))
        self.src_ip  = self.peer[0]
        self.src_port = self.peer[1]
        self.client_id: str = ""
        self.username:  str = ""
        self.password:  str = ""

    def _emit(self, action: str, payload: str = "", raw: dict = None):
        bus.publish({
            "protocol":  "MQTT",
            "src_ip":    self.src_ip,
            "src_port":  self.src_port,
            "action":    action,
            "payload":   payload,
            "raw":       raw or {},
            "timestamp": datetime.utcnow().isoformat(),
        })

    async def handle(self):
        logger.info("MQTT connection from %s:%s", self.src_ip, self.src_port)
        self._emit("CONNECT_ATTEMPT", f"client={self.client_id}")
        try:
            while True:
                header = await self.reader.readexactly(1)
                ptype = header[0] & 0xF0

                # Read remaining length
                remaining = 0
                multiplier = 1
                while True:
                    b = (await self.reader.readexactly(1))[0]
                    remaining += (b & 127) * multiplier
                    multiplier *= 128
                    if not (b & 128):
                        break

                body = b""
                if remaining:
                    body = await self.reader.readexactly(remaining)

                await self._handle_packet(ptype, header[0], body)

        except asyncio.IncompleteReadError:
            pass
        except Exception as e:
            logger.debug("MQTT session error %s:%s — %s", self.src_ip, self.src_port, e)
        finally:
            self._emit("DISCONNECT", "session ended")
            try:
                self.writer.close()
            except Exception:
                pass

    async def _handle_packet(self, ptype: int, flags_byte: int, body: bytes):
        if ptype == CONNECT:
            await self._handle_connect(body)
        elif ptype == PUBLISH:
            await self._handle_publish(flags_byte, body)
        elif ptype == SUBSCRIBE:
            await self._handle_subscribe(body)
        elif ptype == PINGREQ:
            self.writer.write(bytes([PINGRESP, 0x00]))
            await self.writer.drain()
        elif ptype == DISCONNECT:
            self._emit("DISCONNECT", "clean disconnect")
            raise asyncio.IncompleteReadError(b"", 0)

    async def _handle_connect(self, body: bytes):
        offset = 0
        proto_name, offset = read_utf8_string(body, offset)
        proto_level = body[offset]; offset += 1
        connect_flags = body[offset]; offset += 1
        keep_alive    = struct.unpack_from("!H", body, offset)[0]; offset += 2

        client_id, offset = read_utf8_string(body, offset)
        self.client_id = client_id

        # Username / password flags
        has_user = (connect_flags >> 7) & 1
        has_pass = (connect_flags >> 6) & 1
        if has_user and offset < len(body):
            self.username, offset = read_utf8_string(body, offset)
        if has_pass and offset < len(body):
            self.password, offset = read_utf8_string(body, offset)

        self._emit("CONNECT", f"client_id={client_id}", {
            "client_id":     client_id,
            "proto_level":   proto_level,
            "connect_flags": connect_flags,
            "keep_alive":    keep_alive,
            "username":      self.username,
            "password":      self.password,
        })

        if self.username or self.password:
            from honeypot.core import insert_credential
            insert_credential({
                "protocol": "MQTT",
                "src_ip":   self.src_ip,
                "username": self.username,
                "password": self.password,
            })

        # MITIGATION 2: MQTT Credential Enforcement
        code, reason = mqtt_enforcer.check_credentials(
            self.src_ip, self.username, self.password
        )
        if code != CONNACK_ACCEPTED:
            # Send CONNACK with refusal code then close
            self.writer.write(bytes([CONNACK, 0x02, 0x00, code]))
            await self.writer.drain()
            self._emit("CONNECT_REFUSED",
                       f"[MITIGATED] {reason} user={self.username}")
            self.writer.close()
            return
        # end mitigation — accepted
        self.writer.write(bytes([CONNACK, 0x02, 0x00, CONNACK_ACCEPTED]))
        await self.writer.drain()

    async def _handle_publish(self, flags_byte: int, body: bytes):
        qos = (flags_byte >> 1) & 0x03
        offset = 0
        topic, offset = read_utf8_string(body, offset)
        packet_id = None
        if qos > 0:
            packet_id = struct.unpack_from("!H", body, offset)[0]; offset += 2
        payload = body[offset:].decode("utf-8", errors="replace")

        self._emit("PUBLISH", f"topic={topic} payload={payload[:200]}", {
            "topic": topic, "payload": payload, "qos": qos
        })

        if qos == 1 and packet_id is not None:
            self.writer.write(bytes([PUBACK, 0x02]) + struct.pack("!H", packet_id))
            await self.writer.drain()

    async def _handle_subscribe(self, body: bytes):
        offset = 0
        packet_id = struct.unpack_from("!H", body, offset)[0]; offset += 2
        topics = []
        while offset < len(body):
            topic, offset = read_utf8_string(body, offset)
            _qos = body[offset]; offset += 1
            topics.append(topic)

        self._emit("SUBSCRIBE", f"topics={','.join(topics)}", {"topics": topics})

        # SUBACK — grant QoS 0 for each topic
        granted = bytes([0x00] * len(topics))
        suback = bytes([SUBACK]) + encode_remaining_length(2 + len(granted)) \
                 + struct.pack("!H", packet_id) + granted
        self.writer.write(suback)
        await self.writer.drain()


async def _client_connected(reader, writer):
    session = MQTTSession(reader, writer)
    await session.handle()


async def run_mqtt():
    server = await asyncio.start_server(_client_connected, HOST, MQTT_PORT)
    logger.info("MQTT honeypot listening on %s:%s", HOST, MQTT_PORT)
    async with server:
        await server.serve_forever()


def start():
    loop = asyncio.new_event_loop()
    loop.run_until_complete(run_mqtt())
