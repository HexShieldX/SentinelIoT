"""
honeypot/http_honey.py
======================
Fake IoT device HTTP management interface.
Simulates a router/gateway admin panel — logs all requests,
payloads, credentials submitted via forms, and probed paths.
"""

import asyncio
import logging
import re
import json
from datetime import datetime
from urllib.parse import parse_qs, unquote_plus

from config.settings import HOST, HTTP_PORT, FAKE_DEVICE
from honeypot.core import bus, insert_credential

logger = logging.getLogger("honeypot.http")

# ── Fake pages ────────────────────────────────────────────────────────────────

_LOGIN_PAGE = f"""HTTP/1.1 200 OK\r
Content-Type: text/html\r
Server: lighttpd/1.4.54\r
X-Powered-By: SmartHome-GW\r
\r
<!DOCTYPE html><html><head>
<title>{FAKE_DEVICE['model']} — Login</title>
<style>
body{{font-family:Arial;background:#1a1a2e;color:#eee;display:flex;justify-content:center;align-items:center;height:100vh;margin:0}}
.box{{background:#16213e;padding:40px;border-radius:8px;width:320px;border:1px solid #0f3460}}
h2{{text-align:center;color:#e94560}}
input{{width:100%;padding:10px;margin:8px 0;background:#0f3460;border:none;color:#fff;border-radius:4px;box-sizing:border-box}}
button{{width:100%;padding:12px;background:#e94560;border:none;color:#fff;cursor:pointer;border-radius:4px;font-size:15px}}
.logo{{text-align:center;margin-bottom:20px;font-size:12px;color:#888}}
</style></head>

<body>
<div class="box">
<div class="logo">{FAKE_DEVICE['manufacturer']}</div>

<h2>🔒 Admin Login</h2>

<form method="POST" action="/login">
<input name="username" placeholder="Username" />
<input name="password" type="password" placeholder="Password" />
<button type="submit">Login</button>
</form>

<p style="text-align:center;font-size:11px;color:#555;margin-top:20px">
{FAKE_DEVICE['model']} {FAKE_DEVICE['firmware']}
</p>

</div>
</body></html>
"""

_DASHBOARD_PAGE = f"""HTTP/1.1 200 OK\r
Content-Type: text/html\r
Server: lighttpd/1.4.54\r
\r
<!DOCTYPE html><html><head>
<title>{FAKE_DEVICE['model']} — Dashboard</title>
<style>
body{{font-family:Arial;background:#0d1117;color:#cdd9e5;padding:20px}}
.card{{background:#161b22;border:1px solid #30363d;border-radius:6px;padding:20px;margin:10px 0}}
h1{{color:#58a6ff}}
.val{{color:#3fb950;font-size:24px;font-weight:bold}}
</style></head>

<body>
<h1>🏠 {FAKE_DEVICE['model']} Dashboard</h1>

<div class="card"><b>Status:</b> <span style="color:#3fb950">● Online</span></div>
<div class="card"><b>Temperature:</b> <span class="val">23.5 °C</span></div>
<div class="card"><b>Humidity:</b> <span class="val">61.2 %</span></div>
<div class="card"><b>Firmware:</b> {FAKE_DEVICE['firmware']}</div>
<div class="card"><b>Serial:</b> {FAKE_DEVICE['serial']}</div>

<div class="card">
<a href="/api/v1/sensors">/api/v1/sensors</a> |
<a href="/api/v1/config">/api/v1/config</a>
</div>

</body></html>
"""

_API_SENSORS = json.dumps({
    "status": "ok",
    "device": FAKE_DEVICE["model"],
    "sensors": {
        "temperature": 23.5,
        "humidity": 61.2,
        "pressure": 1013.2,
        "motion": False,
        "door": "closed"
    },
    "timestamp": "2026-01-01T00:00:00Z"
})

_API_CONFIG = json.dumps({
    "status": "ok",
    "config": {
        "ssid": "SmartHome_Net",
        "channel": 6,
        "security": "WPA2",
        "mqtt_broker": "192.168.1.100",
        "mqtt_port": 1883,
        "ntp_server": "pool.ntp.org",
        "timezone": "UTC"
    }
})

_404 = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\nNot Found"
_302_DASH = "HTTP/1.1 302 Found\r\nLocation: /dashboard\r\n\r\n"


class HTTPSession:
    def __init__(self, reader, writer):
        self.reader = reader
        self.writer = writer
        self.peer = writer.get_extra_info("peername", ("unknown", 0))
        self.src_ip = self.peer[0]
        self.src_port = self.peer[1]

    def _emit(self, action: str, payload: str = "", raw: dict = None):
        bus.publish({
            "protocol": "HTTP",
            "src_ip": self.src_ip,
            "src_port": self.src_port,
            "action": action,
            "payload": payload[:500],
            "raw": raw or {},
            "timestamp": datetime.utcnow().isoformat(),
        })

    async def handle(self):
        try:
            raw = await asyncio.wait_for(self.reader.read(8192), timeout=15)
            if not raw:
                return

            text = raw.decode("utf-8", errors="replace")
            lines = text.split("\r\n")

            req_line = lines[0]
            parts = req_line.split(" ")

            if len(parts) < 2:
                return

            method, path = parts[0], parts[1]

            headers = {}
            i = 1
            while i < len(lines) and lines[i]:
                if ":" in lines[i]:
                    k, v = lines[i].split(":", 1)
                    headers[k.strip().lower()] = v.strip()
                i += 1

            body = text.split("\r\n\r\n", 1)[1] if "\r\n\r\n" in text else ""

            self._emit("REQUEST", f"{method} {path}", {
                "method": method,
                "path": path,
                "user_agent": headers.get("user-agent", ""),
                "body_preview": body[:200],
            })

            await self._route(method, path, body)

        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug("HTTP error %s — %s", self.src_ip, e)
        finally:
            try:
                self.writer.close()
            except Exception:
                pass

    async def _route(self, method, path, body):
        path_clean = path.split("?")[0].lower()

        if path_clean in ("/", "/login", "/admin"):
            if method == "POST":
                await self._login(body)
            else:
                self.writer.write(_LOGIN_PAGE.encode())

        elif path_clean in ("/dashboard", "/home"):
            self.writer.write(_DASHBOARD_PAGE.encode())

        elif path_clean == "/api/v1/sensors":
            self.writer.write(
                f"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{_API_SENSORS}".encode()
            )

        elif path_clean == "/api/v1/config":
            self.writer.write(
                f"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n{_API_CONFIG}".encode()
            )

        else:
            self._emit("UNKNOWN_PATH", path)
            self.writer.write(_404.encode())

        await self.writer.drain()

    async def _login(self, body: str):
        params = parse_qs(body)

        username = unquote_plus(params.get("username", [""])[0])
        password = unquote_plus(params.get("password", [""])[0])

        self._emit("LOGIN_ATTEMPT", f"user={username} pass={password}")

        insert_credential({
            "protocol": "HTTP",
            "src_ip": self.src_ip,
            "username": username,
            "password": password,
        })

        self.writer.write(_302_DASH.encode())


async def _client_connected(reader, writer):
    session = HTTPSession(reader, writer)
    await session.handle()


async def run_http():
    server = await asyncio.start_server(_client_connected, HOST, HTTP_PORT)
    logger.info("HTTP honeypot listening on %s:%s", HOST, HTTP_PORT)

    async with server:
        await server.serve_forever()


def start():
    loop = asyncio.new_event_loop()
    loop.run_until_complete(run_http())