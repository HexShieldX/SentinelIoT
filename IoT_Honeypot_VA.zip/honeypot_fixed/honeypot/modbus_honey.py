"""
honeypot/modbus_honey.py
========================
Modbus/TCP honeypot — simulates a PLC/SCADA device.
Handles function codes: Read Coils (01), Read Discrete Inputs (02),
Read Holding Registers (03), Read Input Registers (04),
Write Single Coil (05), Write Single Register (06),
Write Multiple Registers (16).
"""
import asyncio
import struct
import logging
from datetime import datetime
from typing import Dict

from config.settings import HOST, MODBUS_PORT, MODBUS_REGISTERS
from honeypot.core import bus

logger = logging.getLogger("honeypot.modbus")

FC_READ_COILS        = 0x01
FC_READ_DISCRETE     = 0x02
FC_READ_HOLDING_REGS = 0x03
FC_READ_INPUT_REGS   = 0x04
FC_WRITE_SINGLE_COIL = 0x05
FC_WRITE_SINGLE_REG  = 0x06
FC_WRITE_MULTI_REGS  = 0x10

# Fake coil state
_COILS: Dict[int, int] = {i: 0 for i in range(32)}
_COILS[0] = 1; _COILS[3] = 1  # some coils ON

# Holding registers (same as settings, mutable)
_REGS: Dict[int, int] = dict(MODBUS_REGISTERS)


def _build_mbap(tid: int, unit: int, pdu: bytes) -> bytes:
    """Build Modbus Application Protocol header + PDU."""
    return struct.pack("!HHHB", tid, 0, len(pdu) + 1, unit) + pdu


class ModbusSession:
    def __init__(self, reader, writer):
        self.reader   = reader
        self.writer   = writer
        self.peer     = writer.get_extra_info("peername", ("unknown", 0))
        self.src_ip   = self.peer[0]
        self.src_port = self.peer[1]

    def _emit(self, action: str, payload: str = "", raw: dict = None):
        bus.publish({
            "protocol":  "MODBUS",
            "src_ip":    self.src_ip,
            "src_port":  self.src_port,
            "action":    action,
            "payload":   payload,
            "raw":       raw or {},
            "timestamp": datetime.utcnow().isoformat(),
        })

    async def handle(self):
        logger.info("Modbus connection from %s:%s", self.src_ip, self.src_port)
        self._emit("CONNECT", "new Modbus/TCP connection")
        try:
            while True:
                # MBAP header: 7 bytes
                header = await asyncio.wait_for(self.reader.readexactly(7), timeout=60)
                tid, proto_id, length, unit_id = struct.unpack("!HHHB", header)
                if proto_id != 0:
                    continue
                pdu = await self.reader.readexactly(length - 1)
                if not pdu:
                    break
                response_pdu = self._process(pdu, unit_id)
                if response_pdu:
                    self.writer.write(_build_mbap(tid, unit_id, response_pdu))
                    await self.writer.drain()
        except asyncio.IncompleteReadError:
            pass
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            logger.debug("Modbus session error %s — %s", self.src_ip, e)
        finally:
            self._emit("DISCONNECT")
            try:
                self.writer.close()
            except Exception:
                pass

    def _process(self, pdu: bytes, unit: int) -> bytes:
        fc = pdu[0]
        data = pdu[1:]

        if fc == FC_READ_COILS:
            start, count = struct.unpack("!HH", data[:4])
            self._emit("READ_COILS", f"start={start} count={count} unit={unit}")
            vals = [_COILS.get(start + i, 0) for i in range(min(count, 32))]
            byte_count = (len(vals) + 7) // 8
            coil_bytes = bytearray(byte_count)
            for i, v in enumerate(vals):
                if v:
                    coil_bytes[i // 8] |= (1 << (i % 8))
            return bytes([fc, byte_count]) + bytes(coil_bytes)

        elif fc == FC_READ_DISCRETE:
            start, count = struct.unpack("!HH", data[:4])
            self._emit("READ_DISCRETE_INPUTS", f"start={start} count={count}")
            vals = [_COILS.get(start + i, 0) for i in range(min(count, 32))]
            byte_count = (len(vals) + 7) // 8
            inp_bytes = bytearray(byte_count)
            for i, v in enumerate(vals):
                if v:
                    inp_bytes[i // 8] |= (1 << (i % 8))
            return bytes([fc, byte_count]) + bytes(inp_bytes)

        elif fc in (FC_READ_HOLDING_REGS, FC_READ_INPUT_REGS):
            start, count = struct.unpack("!HH", data[:4])
            label = "READ_HOLDING_REGS" if fc == FC_READ_HOLDING_REGS else "READ_INPUT_REGS"
            self._emit(label, f"start={start} count={count} unit={unit}")
            regs = [_REGS.get(start + i, 0) for i in range(min(count, 125))]
            byte_count = len(regs) * 2
            reg_bytes = b"".join(struct.pack("!H", r) for r in regs)
            return bytes([fc, byte_count]) + reg_bytes

        elif fc == FC_WRITE_SINGLE_COIL:
            addr, value = struct.unpack("!HH", data[:4])
            _COILS[addr] = 1 if value == 0xFF00 else 0
            self._emit("WRITE_COIL", f"addr={addr} value={value} unit={unit}")
            return bytes([fc]) + data[:4]  # echo back

        elif fc == FC_WRITE_SINGLE_REG:
            addr, value = struct.unpack("!HH", data[:4])
            _REGS[addr] = value
            self._emit("WRITE_REGISTER", f"addr={addr} value={value} unit={unit}")
            return bytes([fc]) + data[:4]

        elif fc == FC_WRITE_MULTI_REGS:
            start, count = struct.unpack("!HH", data[:4])
            byte_count = data[4]
            values = struct.unpack(f"!{count}H", data[5:5 + count * 2])
            for i, v in enumerate(values):
                _REGS[start + i] = v
            self._emit("WRITE_MULTI_REGS",
                       f"start={start} count={count} values={list(values)[:10]} unit={unit}")
            return bytes([fc]) + data[:4]

        else:
            # Unknown FC — log and return exception response
            self._emit("UNKNOWN_FUNCTION_CODE", f"fc=0x{fc:02X} unit={unit}")
            return bytes([fc | 0x80, 0x01])  # illegal function


async def _client_connected(reader, writer):
    session = ModbusSession(reader, writer)
    await session.handle()


async def run_modbus():
    server = await asyncio.start_server(_client_connected, HOST, MODBUS_PORT)
    logger.info("Modbus honeypot listening on %s:%s", HOST, MODBUS_PORT)
    async with server:
        await server.serve_forever()


def start():
    loop = asyncio.new_event_loop()
    loop.run_until_complete(run_modbus())
