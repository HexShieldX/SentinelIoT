# Cloud Deployment Guide — AWS EC2

## 1. Launch EC2 Instance

- **AMI**: Ubuntu 22.04 LTS (64-bit)
- **Instance type**: t3.small (2 vCPU, 2 GB RAM) minimum; t3.medium recommended
- **Storage**: 20 GB gp3

## 2. Security Group — Inbound Rules

| Type       | Protocol | Port Range | Source    | Purpose              |
|------------|----------|------------|-----------|----------------------|
| Custom TCP | TCP      | 23         | 0.0.0.0/0 | Telnet honeypot      |
| Custom TCP | TCP      | 502        | 0.0.0.0/0 | Modbus honeypot      |
| Custom TCP | TCP      | 1883       | 0.0.0.0/0 | MQTT honeypot        |
| Custom TCP | TCP      | 2222       | 0.0.0.0/0 | SSH honeypot         |
| Custom TCP | TCP      | 5000       | YOUR_IP/32| Dashboard (restrict!)|
| Custom UDP | UDP      | 5683       | 0.0.0.0/0 | CoAP honeypot        |
| Custom TCP | TCP      | 8080       | 0.0.0.0/0 | HTTP honeypot        |
| SSH        | TCP      | 22         | YOUR_IP/32| Your management SSH  |

> ⚠️  IMPORTANT: Restrict port 5000 (dashboard) to YOUR IP only.
>    Never expose the dashboard to the public internet.

## 3. Install Docker on Ubuntu

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo usermod -aG docker ubuntu
newgrp docker
```

## 4. Deploy the Honeypot

```bash
# Upload project (from your local machine)
scp -r ./honeypot ubuntu@<EC2_PUBLIC_IP>:~/honeypot
ssh ubuntu@<EC2_PUBLIC_IP>

# On the EC2 instance
cd ~/honeypot

# Set a strong secret key
export SECRET_KEY="$(openssl rand -hex 32)"
echo "SECRET_KEY=$SECRET_KEY" > .env

# (Optional) Download GeoLite2 DB for attacker geolocation
# Register free at https://www.maxmind.com/en/geolite2/signup
# then: wget -O GeoLite2-City.mmdb "YOUR_DOWNLOAD_URL"

# Build and start
docker compose --env-file .env up -d --build

# Check logs
docker compose logs -f

# Dashboard URL
echo "Dashboard: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):5000"
```

## 5. (Optional) GCP / Azure equivalents

### Google Cloud (GCP)
```bash
gcloud compute instances create honeypot \
  --machine-type=e2-small \
  --image-family=ubuntu-2204-lts \
  --image-project=ubuntu-os-cloud \
  --tags=honeypot

gcloud compute firewall-rules create honeypot-ports \
  --target-tags=honeypot \
  --allow=tcp:23,tcp:502,tcp:1883,tcp:2222,tcp:8080,udp:5683
# Add tcp:5000 restricted to your IP separately
```

### Azure
```bash
az vm create --resource-group honeypot-rg --name honeypot-vm \
  --image Ubuntu2204 --size Standard_B1ms \
  --admin-username azureuser --generate-ssh-keys

az vm open-port --resource-group honeypot-rg --name honeypot-vm \
  --port 23,502,1883,2222,8080 --priority 100
```

## 6. Maintenance

```bash
# View live logs
docker compose logs -f honeypot

# Restart
docker compose restart

# Update and rebuild
git pull && docker compose up -d --build

# Backup the database
docker cp iot-honeypot:/app/logs/honeypot.db ./honeypot_backup_$(date +%F).db

# Stop
docker compose down
```

## 7. Security Hardening

- Run the honeypot on a **dedicated, isolated** instance
- Never expose the dashboard port (5000) publicly — use SSH tunnel:
  ```bash
  ssh -L 5000:localhost:5000 ubuntu@<EC2_IP>
  # Then open http://localhost:5000 in your browser
  ```
- Rotate `SECRET_KEY` regularly
- Monitor egress traffic — honeypot should not make outbound connections
- Set up AWS CloudWatch or VPC Flow Logs for additional visibility
- Consider AWS WAF in front of port 8080 for extra HTTP logging
