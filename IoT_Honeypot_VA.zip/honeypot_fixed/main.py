"""
main.py
=======
IoT Deception Honeypot — main entrypoint.
Starts all protocol honeypots, the ML anomaly detector,
and the web dashboard as concurrent threads/processes.
"""

import sys
import os
import threading
import logging
import time
import signal

# Ensure project root is in path
sys.path.insert(0, os.path.dirname(__file__))

from honeypot.core import init_db, load_geoip, bus, logger
from ml.anomaly import detector
from va.va_engine import init_va_db, on_event as va_on_event
from mitigation.mitigations import init_mitigation_db
from config.settings import (
    HOST, MQTT_PORT, TELNET_PORT, SSH_PORT, HTTP_PORT,
    MODBUS_PORT, COAP_PORT, DASHBOARD_PORT
)

# Register anomaly detector and VA engine on event bus
bus.subscribe(detector.on_event)
bus.subscribe(va_on_event)

# ── Service definitions ───────────────────────────────────────────────────────

def _run_mqtt():
    from honeypot.mqtt_honey import start
    try:
        start()
    except Exception as e:
        logger.error("MQTT service crashed: %s", e)

def _run_telnet():
    from honeypot.telnet_honey import start
    try:
        start()
    except Exception as e:
        logger.error("Telnet service crashed: %s", e)

def _run_ssh():
    from honeypot.ssh_honey import start
    try:
        start()
    except Exception as e:
        logger.error("SSH service crashed: %s", e)

def _run_http():
    from honeypot.http_honey import start
    try:
        start()
    except Exception as e:
        logger.error("HTTP service crashed: %s", e)

def _run_modbus():
    from honeypot.modbus_honey import start
    try:
        start()
    except Exception as e:
        logger.error("Modbus service crashed: %s", e)

def _run_coap():
    from honeypot.coap_honey import start
    try:
        start()
    except Exception as e:
        logger.error("CoAP service crashed: %s", e)

def _run_dashboard():
    from dashboard.app import run_dashboard
    try:
        run_dashboard()
    except Exception as e:
        logger.error("Dashboard crashed: %s", e)


SERVICES = [
    ("MQTT", _run_mqtt),
    ("Telnet", _run_telnet),
    ("SSH", _run_ssh),
    ("HTTP", _run_http),
    ("Modbus", _run_modbus),
    ("CoAP", _run_coap),
    ("Dashboard", _run_dashboard),
]


def print_banner():
    print(f"""
╔══════════════════════════════════════════════════════════╗
║          IoT Deception Honeypot  —  Starting Up          ║
╠══════════════════════════════════════════════════════════╣
║  Protocol Services:                                      ║
║    MQTT     → port {MQTT_PORT:<5}                         ║
║    Telnet   → port {TELNET_PORT:<5}                      ║
║    SSH      → port {SSH_PORT:<5}                         ║
║    HTTP     → port {HTTP_PORT:<5}                        ║
║    Modbus   → port {MODBUS_PORT:<5}                      ║
║    CoAP     → port {COAP_PORT:<5} (UDP)                  ║
║  Dashboard  → http://0.0.0.0:{DASHBOARD_PORT:<5}         ║
╚══════════════════════════════════════════════════════════╝
    """)


def main():
    print_banner()

    # DB init
    init_db()
    init_va_db()
    init_mitigation_db()

    # ✅ FIXED: GeoIP will NEVER crash the app now
    try:
        load_geoip()
        logger.info("GeoIP loaded successfully")
    except Exception as e:
        logger.warning("GeoIP disabled (missing or invalid DB): %s", e)

    # Start services
    threads = []
    for name, target in SERVICES:
        t = threading.Thread(target=target, name=name, daemon=True)
        t.start()
        threads.append(t)
        logger.info("Started %s service", name)
        time.sleep(0.3)

    logger.info("All services running. Dashboard → http://0.0.0.0:%s", DASHBOARD_PORT)
    logger.info("Press Ctrl+C to stop.")

    # Graceful shutdown
    def _shutdown(sig, frame):
        logger.info("Shutting down honeypot...")
        sys.exit(0)

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    # Watchdog loop
    while True:
        time.sleep(5)
        for t in threads:
            if not t.is_alive():
                logger.warning("Service thread '%s' is not alive!", t.name)


if __name__ == "__main__":
    main()
