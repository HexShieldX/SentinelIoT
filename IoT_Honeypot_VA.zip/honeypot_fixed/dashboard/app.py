"""
dashboard/app.py
================
Flask-based real-time dashboard.
- SSE stream for live event feed
- REST API for stats / events / credentials
- Map data endpoint for attacker geolocation
"""
import json
import queue
import threading
import time
import logging
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, jsonify, Response,
                   request, stream_with_context)

from config.settings import DASHBOARD_PORT, SECRET_KEY, DB_PATH
from honeypot.core import (bus, get_stats, query_events,
                            get_db, _DB_LOCK)

logger = logging.getLogger("honeypot.dashboard")

app = Flask(__name__)
app.secret_key = SECRET_KEY

# ── SSE client queues ─────────────────────────────────────────────────────────
_sse_clients: list = []
_sse_lock = threading.Lock()

def _sse_broadcast(event: dict):
    msg = f"data: {json.dumps(event)}\n\n"
    with _sse_lock:
        dead = []
        for q in _sse_clients:
            try:
                q.put_nowait(msg)
            except Exception:
                dead.append(q)
        for q in dead:
            _sse_clients.remove(q)

bus.subscribe(_sse_broadcast)


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/stats")
def api_stats():
    return jsonify(get_stats())


@app.route("/api/events")
def api_events():
    limit    = min(int(request.args.get("limit",  200)), 1000)
    protocol = request.args.get("protocol", None)
    anomaly  = request.args.get("anomaly",  "false").lower() == "true"
    events   = query_events(limit=limit, protocol=protocol, anomaly_only=anomaly)
    return jsonify(events)


@app.route("/api/credentials")
def api_credentials():
    with _DB_LOCK:
        conn = get_db()
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM credentials ORDER BY id DESC LIMIT 500"
        ).fetchall()]
        conn.close()
    return jsonify(rows)


@app.route("/api/sessions")
def api_sessions():
    with _DB_LOCK:
        conn = get_db()
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM sessions ORDER BY id DESC LIMIT 200"
        ).fetchall()]
        conn.close()
    return jsonify(rows)


@app.route("/api/map")
def api_map():
    """Return attacker locations for the geo map."""
    with _DB_LOCK:
        conn = get_db()
        rows = [dict(r) for r in conn.execute(
            """SELECT src_ip, country, city, latitude, longitude,
                      COUNT(*) as count, MAX(timestamp) as last_seen
               FROM events
               WHERE latitude != 0 AND longitude != 0
               GROUP BY src_ip"""
        ).fetchall()]
        conn.close()
    return jsonify(rows)


@app.route("/api/timeline")
def api_timeline():
    """Events per hour for the last 24 h, broken down by protocol."""
    with _DB_LOCK:
        conn = get_db()
        rows = conn.execute(
            """SELECT strftime('%Y-%m-%dT%H:00:00', timestamp) as hour,
                      protocol, COUNT(*) as count
               FROM events
               WHERE timestamp >= datetime('now', '-24 hours')
               GROUP BY hour, protocol
               ORDER BY hour"""
        ).fetchall()
        conn.close()
    return jsonify([dict(r) for r in rows])


@app.route("/api/anomalies")
def api_anomalies():
    events = query_events(limit=100, anomaly_only=True)
    return jsonify(events)


@app.route("/stream")
def stream():
    """Server-Sent Events endpoint for real-time event feed."""
    q: queue.Queue = queue.Queue(maxsize=200)
    with _sse_lock:
        _sse_clients.append(q)

    def generate():
        yield "data: {\"type\":\"connected\"}\n\n"
        while True:
            try:
                msg = q.get(timeout=20)
                yield msg
            except queue.Empty:
                yield ": heartbeat\n\n"  # keep connection alive

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control":  "no-cache",
            "X-Accel-Buffering": "no",
        }
    )


@app.route("/api/va/findings")
def api_va_findings():
    from va.va_engine import get_va_findings
    severity = request.args.get("severity")
    protocol = request.args.get("protocol")
    limit    = min(int(request.args.get("limit", 500)), 2000)
    findings = get_va_findings(limit=limit, severity=severity, protocol=protocol)
    return jsonify(findings)


@app.route("/api/va/summary")
def api_va_summary():
    from va.va_engine import generate_va_summary
    return jsonify(generate_va_summary())


@app.route("/api/va/catalogue")
def api_va_catalogue():
    from va.va_engine import VULN_CATALOGUE, OWASP_IOT_TOP10, MITRE_TECHNIQUES
    return jsonify({
        "vulnerabilities": VULN_CATALOGUE,
        "owasp_iot_top10": OWASP_IOT_TOP10,
        "mitre_techniques": MITRE_TECHNIQUES,
    })


@app.route("/va")
def va_dashboard():
    return render_template("va.html")


def run_dashboard():
    logger.info("Dashboard starting on port %s", DASHBOARD_PORT)
    app.run(host="0.0.0.0", port=DASHBOARD_PORT,
            debug=False, threaded=True, use_reloader=False)


@app.route("/api/mitigation/stats")
def api_mitigation_stats():
    from mitigation.mitigations import get_mitigation_stats
    return jsonify(get_mitigation_stats())

@app.route("/api/mitigation/block", methods=["POST"])
def api_mitigation_block():
    from mitigation.mitigations import ssh_blocker
    data = request.get_json(force=True)
    ip = data.get("ip","").strip()
    dur = int(data.get("duration", 3600))
    if not ip:
        return jsonify({"error":"ip required"}), 400
    ssh_blocker.manual_block(ip, dur)
    return jsonify({"status":"blocked", "ip":ip, "duration":dur})

@app.route("/api/mitigation/unblock", methods=["POST"])
def api_mitigation_unblock():
    from mitigation.mitigations import ssh_blocker
    data = request.get_json(force=True)
    ip = data.get("ip","").strip()
    if not ip:
        return jsonify({"error":"ip required"}), 400
    ssh_blocker.manual_unblock(ip)
    return jsonify({"status":"unblocked", "ip":ip})

@app.route("/mitigation")
def mitigation_dashboard():
    return render_template("mitigation.html")
