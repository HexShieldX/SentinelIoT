# IoT Deception Honeypot

A professional-grade, cloud-ready IoT honeypot that simulates six protocols, detects anomalies with AI, and visualises attacks in real time through a built-in web dashboard.

## Architecture

```
honeypot/
├── honeypot/
│   ├── core.py          # Event bus, DB, GeoIP, logging
│   ├── mqtt_honey.py    # MQTT broker simulator   (port 1883)
│   ├── telnet_honey.py  # Telnet simulator         (port 23)
│   ├── ssh_honey.py     # SSH simulator            (port 22 / 2222)
│   ├── http_honey.py    # HTTP device UI sim       (port 8080)
│   ├── modbus_honey.py  # Modbus/TCP simulator     (port 502)
│   └── coap_honey.py    # CoAP simulator           (port 5683 UDP)
├── dashboard/
│   ├── app.py           # Flask dashboard + REST API
│   ├── templates/       # Jinja2 HTML
│   └── static/          # CSS / JS
├── ml/
│   └── anomaly.py       # Isolation Forest anomaly detector
├── config/
│   └── settings.py      # Central configuration
├── main.py              # Entrypoint — starts all services
├── requirements.txt
├── Dockerfile
└── docker-compose.yml
```

## Quick Start (Docker — recommended for cloud)

```bash
# Clone / copy the project
cd honeypot

# Build and run
docker-compose up -d --build

# Dashboard
open http://<YOUR_IP>:5000
```

## Manual Start (virtualenv)

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python main.py
```

## Ports

| Service    | Port      | Protocol |
|------------|-----------|----------|
| MQTT       | 1883      | TCP      |
| Telnet     | 23        | TCP      |
| SSH        | 2222      | TCP      |
| HTTP       | 8080      | TCP      |
| Modbus     | 502       | TCP      |
| CoAP       | 5683      | UDP      |
| Dashboard  | 5000      | TCP      |

## Cloud Deployment (AWS example)

1. Launch Ubuntu 22.04 EC2 (t3.small or larger)
2. Open Security Group inbound: 22, 23, 502, 1883, 2222, 5000, 5683/UDP, 8080
3. SSH in, install Docker + Docker Compose
4. `git clone` / `scp` this project, then `docker-compose up -d --build`

## Environment Variables

| Variable          | Default       | Description                  |
|-------------------|---------------|------------------------------|
| `HONEYPOT_HOST`   | `0.0.0.0`     | Bind address                 |
| `DASHBOARD_PORT`  | `5000`        | Dashboard port               |
| `LOG_LEVEL`       | `INFO`        | Logging verbosity            |
| `ANOMALY_THRESH`  | `-0.1`        | Isolation Forest threshold   |
| `SECRET_KEY`      | `changeme`    | Flask session secret         |
