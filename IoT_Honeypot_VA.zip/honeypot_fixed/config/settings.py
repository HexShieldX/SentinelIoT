"""
config/settings.py — Central configuration for IoT Honeypot
All values can be overridden via environment variables.
"""
import os

# ── Bind address ────────────────────────────────────────────────────────────
HOST = os.getenv("HONEYPOT_HOST", "0.0.0.0")

# ── Protocol ports ──────────────────────────────────────────────────────────
MQTT_PORT    = int(os.getenv("MQTT_PORT",    1883))
TELNET_PORT  = int(os.getenv("TELNET_PORT",  23))
SSH_PORT     = int(os.getenv("SSH_PORT",     2222))   # use 22 in prod (requires root)
HTTP_PORT    = int(os.getenv("HTTP_PORT",    8080))
MODBUS_PORT  = int(os.getenv("MODBUS_PORT",  502))
COAP_PORT    = int(os.getenv("COAP_PORT",    5683))

# ── Dashboard ───────────────────────────────────────────────────────────────
DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", 5000))
SECRET_KEY     = os.getenv("SECRET_KEY", "changeme-use-a-real-secret-in-prod")

# ── Database ────────────────────────────────────────────────────────────────
DB_PATH = os.getenv("DB_PATH", "logs/honeypot.db")

# ── Logging ─────────────────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE  = os.getenv("LOG_FILE",  "logs/honeypot.log")

# ── AI Anomaly Detection ────────────────────────────────────────────────────
ANOMALY_THRESHOLD       = float(os.getenv("ANOMALY_THRESH", "-0.1"))
ANOMALY_RETRAIN_EVERY   = int(os.getenv("ANOMALY_RETRAIN_EVERY", "500"))   # events
ANOMALY_MIN_SAMPLES     = int(os.getenv("ANOMALY_MIN_SAMPLES",   "50"))

# ── Fake device identity (returned by HTTP / MQTT / Telnet banners) ─────────
FAKE_DEVICE = {
    "manufacturer": "SmartHome Inc.",
    "model":        "SH-Gateway-3000",
    "firmware":     "v2.1.4",
    "serial":       "SH-3000-X82B1C",
    "api_version":  "1.3",
}

# ── Fake Telnet / SSH credentials (always succeed to trap attacker) ─────────
HONEY_CREDENTIALS = [
    ("admin",    "admin"),
    ("root",     "root"),
    ("admin",    "password"),
    ("admin",    "1234"),
    ("user",     "user"),
    ("guest",    "guest"),
]

# ── Fake Modbus register map ─────────────────────────────────────────────────
MODBUS_REGISTERS = {
    0:  ("Temperature",  2350),   # 23.50 °C  (× 100)
    1:  ("Humidity",     6120),   # 61.20 %
    2:  ("Pressure",     10132),  # 1013.2 hPa
    3:  ("Door_Sensor",  1),      # 1 = closed
    4:  ("Motion",       0),      # 0 = no motion
    10: ("Relay_1",      0),
    11: ("Relay_2",      1),
}

# ── Fake MQTT topics ─────────────────────────────────────────────────────────
MQTT_TOPICS = [
    "home/sensor/temperature",
    "home/sensor/humidity",
    "home/alarm/status",
    "home/door/lock",
    "factory/plc/status",
    "factory/conveyor/speed",
]
