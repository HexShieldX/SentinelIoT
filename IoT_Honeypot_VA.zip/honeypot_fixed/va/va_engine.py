"""
va/va_engine.py
===============
Vulnerability Assessment Engine — maps honeypot observations to
industry-standard frameworks: CVE/CVSS v3.1, OWASP IoT Top 10 (2023),
MITRE ATT&CK for ICS/IoT, and CWE.

Lifecycle stages (NIST SP 800-30 Rev 1):
  1. IDENTIFICATION  — detect what happened
  2. ANALYSIS        — determine severity (CVSS)
  3. RISK ASSESSMENT — likelihood × impact
  4. REMEDIATION     — prescribe countermeasures
  5. REPORTING       — structured finding output
"""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from config.settings import DB_PATH

logger = logging.getLogger("honeypot.va")

# ─────────────────────────────────────────────────────────────────────────────
# CVSS v3.1 Base-Score calculation (simplified — covers what the honeypot sees)
# ─────────────────────────────────────────────────────────────────────────────

CVSS_WEIGHTS = {
    # Attack Vector
    "AV": {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20},
    # Attack Complexity
    "AC": {"L": 0.77, "H": 0.44},
    # Privileges Required
    "PR": {"N": 0.85, "L": 0.62, "H": 0.27},
    # User Interaction
    "UI": {"N": 0.85, "R": 0.62},
    # Scope
    "S":  {"U": "unchanged", "C": "changed"},
    # Confidentiality / Integrity / Availability
    "C":  {"N": 0.00, "L": 0.22, "H": 0.56},
    "I":  {"N": 0.00, "L": 0.22, "H": 0.56},
    "A":  {"N": 0.00, "L": 0.22, "H": 0.56},
}


def cvss_score(av="N", ac="L", pr="N", ui="N", s="U",
               c="H", i="H", a="H") -> Tuple[float, str]:
    """
    Compute CVSS v3.1 base score and severity label.
    Returns (score: float, severity: str).
    """
    AV = CVSS_WEIGHTS["AV"][av]
    AC = CVSS_WEIGHTS["AC"][ac]
    PR_val = CVSS_WEIGHTS["PR"][pr]
    UI_val = CVSS_WEIGHTS["UI"][ui]
    C_val  = CVSS_WEIGHTS["C"][c]
    I_val  = CVSS_WEIGHTS["I"][i]
    A_val  = CVSS_WEIGHTS["A"][a]

    # Modified PR for Scope Changed
    if s == "C" and pr == "L":
        PR_val = 0.50
    elif s == "C" and pr == "H":
        PR_val = 0.50

    ISS = 1 - ((1 - C_val) * (1 - I_val) * (1 - A_val))
    if s == "U":
        Impact = 6.42 * ISS
    else:
        Impact = 7.52 * (ISS - 0.029) - 3.25 * ((ISS - 0.02) ** 15)

    Exploitability = 8.22 * AV * AC * PR_val * UI_val

    if Impact <= 0:
        base = 0.0
    else:
        if s == "U":
            base = min(Impact + Exploitability, 10)
        else:
            base = min(1.08 * (Impact + Exploitability), 10)

    base = round(base * 10) / 10  # round to 1 decimal

    if base == 0.0:
        severity = "NONE"
    elif base < 4.0:
        severity = "LOW"
    elif base < 7.0:
        severity = "MEDIUM"
    elif base < 9.0:
        severity = "HIGH"
    else:
        severity = "CRITICAL"

    return base, severity


# ─────────────────────────────────────────────────────────────────────────────
# OWASP IoT Top 10 (2023) + MITRE ATT&CK for ICS/IoT + CWE mappings
# ─────────────────────────────────────────────────────────────────────────────

OWASP_IOT_TOP10 = {
    "IOT1":  "Weak, Guessable, or Hardcoded Passwords",
    "IOT2":  "Insecure Network Services",
    "IOT3":  "Insecure Ecosystem Interfaces",
    "IOT4":  "Lack of Secure Update Mechanism",
    "IOT5":  "Use of Insecure or Outdated Components",
    "IOT6":  "Insufficient Privacy Protection",
    "IOT7":  "Insecure Data Transfer and Storage",
    "IOT8":  "Lack of Device Management",
    "IOT9":  "Insecure Default Settings",
    "IOT10": "Lack of Physical Hardening",
}

MITRE_TECHNIQUES = {
    "T0800": "Activate Firmware Update Mode",
    "T0801": "Monitor Process State",
    "T0805": "Block Serial COM",
    "T0811": "Data from Information Repositories",
    "T0818": "Engineering Workstation Compromise",
    "T0819": "Exploit Public-Facing Application",
    "T0820": "Exploitation for Evasion",
    "T0843": "Program Download",
    "T0846": "Remote System Discovery",
    "T0848": "Rogue Master",
    "T0855": "Unauthorized Command Message",
    "T0861": "Point & Tag Identification",
    "T0869": "Standard Application Layer Protocol",
    "T1190": "Exploit Public-Facing Application",
    "T1078": "Valid Accounts",
    "T1110": "Brute Force",
    "T1046": "Network Service Discovery",
    "T1040": "Network Sniffing",
    "T1048": "Exfiltration Over Alternative Protocol",
}

# ─────────────────────────────────────────────────────────────────────────────
# Vulnerability definition catalogue
# Each entry maps an observable pattern → full VA finding
# ─────────────────────────────────────────────────────────────────────────────

VULN_CATALOGUE: List[Dict[str, Any]] = [
    # ── SSH ────────────────────────────────────────────────────────────────
    {
        "id": "VA-SSH-001",
        "title": "Default/Weak SSH Credentials Accepted",
        "description": (
            "The device accepts authentication with default or trivially guessable "
            "credentials (e.g., root/root, admin/admin). An attacker gaining shell "
            "access has full device control."
        ),
        "protocol": "SSH",
        "trigger_actions": ["AUTH_PASSWORD"],
        "cve_refs": ["CVE-2022-27255", "CVE-2021-20090"],
        "cwe": ["CWE-521", "CWE-1392"],
        "owasp_iot": ["IOT1", "IOT9"],
        "mitre": ["T1078", "T1110"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="C", c="H", i="H", a="H"),
        "likelihood": "HIGH",
        "impact": "CRITICAL",
        "stage": "ANALYSIS",
        "remediation": [
            "Disable default accounts or enforce mandatory password change on first boot.",
            "Implement account lockout after 5 failed attempts (CIS Control 5.2).",
            "Require SSH key-based authentication; disable password auth in /etc/ssh/sshd_config.",
            "Rotate factory default credentials before device shipment.",
        ],
    },
    {
        "id": "VA-SSH-002",
        "title": "SSH Brute-Force Attack Detected",
        "description": (
            "Multiple rapid authentication attempts from the same source IP indicate "
            "an automated credential stuffing or brute-force campaign against SSH."
        ),
        "protocol": "SSH",
        "trigger_actions": ["AUTH_PASSWORD"],
        "trigger_threshold": 5,  # ≥5 attempts from same IP
        "cve_refs": [],
        "cwe": ["CWE-307", "CWE-798"],
        "owasp_iot": ["IOT1", "IOT2"],
        "mitre": ["T1110", "T1046"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="H", i="L", a="L"),
        "likelihood": "HIGH",
        "impact": "HIGH",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Deploy fail2ban or equivalent — ban IPs after 5 failures within 60 s.",
            "Rate-limit SSH connections per source IP at the firewall/iptables level.",
            "Move SSH to a non-standard port to reduce automated scanning noise.",
            "Enable SIEM alerting on repeated SSH failures (ISO 27001 A.12.4).",
        ],
    },
    {
        "id": "VA-SSH-003",
        "title": "SSH Post-Exploitation Commands Captured",
        "description": (
            "After successful authentication the attacker issued shell commands "
            "(reconnaissance, file download, or persistence). This indicates active "
            "exploitation beyond credential theft."
        ),
        "protocol": "SSH",
        "trigger_actions": ["COMMAND"],
        "cve_refs": [],
        "cwe": ["CWE-284", "CWE-269"],
        "owasp_iot": ["IOT3", "IOT8"],
        "mitre": ["T0811", "T0843", "T0855"],
        "cvss_vector": dict(av="N", ac="L", pr="L", ui="N", s="C", c="H", i="H", a="H"),
        "likelihood": "MEDIUM",
        "impact": "CRITICAL",
        "stage": "RISK_ASSESSMENT",
        "remediation": [
            "Harden shell environment: restrict PATH, disable wget/curl for non-root.",
            "Enable auditd / Linux Audit Framework to log all exec() calls.",
            "Use read-only root filesystem on embedded devices (squashfs + overlay).",
            "Implement application whitelisting; block unknown binaries.",
        ],
    },

    # ── TELNET ─────────────────────────────────────────────────────────────
    {
        "id": "VA-TEL-001",
        "title": "Telnet Service Exposed on IoT Device",
        "description": (
            "Telnet transmits all data including credentials in cleartext. "
            "Its presence on an Internet-facing IoT device is a critical risk "
            "and violates multiple compliance frameworks."
        ),
        "protocol": "TELNET",
        "trigger_actions": ["CONNECT", "LOGIN"],
        "cve_refs": ["CVE-2023-20076"],
        "cwe": ["CWE-319", "CWE-312"],
        "owasp_iot": ["IOT2", "IOT7"],
        "mitre": ["T1040", "T1078", "T0869"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="C", c="H", i="H", a="H"),
        "likelihood": "HIGH",
        "impact": "CRITICAL",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Disable Telnet completely; replace with SSH 2.0 (NIST SP 800-115 §3.1).",
            "Block port 23 at the network perimeter and device firewall.",
            "If Telnet required for legacy reasons, restrict to isolated management VLAN.",
            "Audit firmware for inetd/xinetd Telnet entries and remove.",
        ],
    },

    # ── HTTP ───────────────────────────────────────────────────────────────
    {
        "id": "VA-HTTP-001",
        "title": "Unencrypted HTTP Management Interface",
        "description": (
            "The device exposes its admin interface over plain HTTP (no TLS). "
            "Credentials and session tokens are transmitted in cleartext, "
            "enabling trivial MITM credential theft."
        ),
        "protocol": "HTTP",
        "trigger_actions": ["LOGIN_ATTEMPT", "GET", "POST"],
        "cve_refs": ["CVE-2023-27997"],
        "cwe": ["CWE-319", "CWE-614"],
        "owasp_iot": ["IOT3", "IOT7"],
        "mitre": ["T1040", "T0819"],
        "cvss_vector": dict(av="N", ac="H", pr="N", ui="R", s="U", c="H", i="L", a="N"),
        "likelihood": "HIGH",
        "impact": "HIGH",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Enforce HTTPS with TLS 1.2+ only; disable HTTP or redirect to HTTPS.",
            "Implement HSTS header (max-age ≥ 31536000) to prevent protocol downgrade.",
            "Use Let's Encrypt or device-provisioned certificates; avoid self-signed.",
            "Apply OWASP TLS Cheat Sheet recommendations for cipher suite hardening.",
        ],
    },
    {
        "id": "VA-HTTP-002",
        "title": "Admin Credential Submission via HTTP",
        "description": (
            "An attacker submitted credentials to the HTTP login endpoint. "
            "Over plaintext HTTP, these credentials are interceptable by any "
            "on-path observer."
        ),
        "protocol": "HTTP",
        "trigger_actions": ["LOGIN_ATTEMPT"],
        "cve_refs": [],
        "cwe": ["CWE-522", "CWE-319"],
        "owasp_iot": ["IOT1", "IOT3"],
        "mitre": ["T1078", "T1110"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="H", i="H", a="N"),
        "likelihood": "HIGH",
        "impact": "HIGH",
        "stage": "ANALYSIS",
        "remediation": [
            "Require HTTPS for all form POSTs; set Secure flag on session cookies.",
            "Implement CSRF tokens on all state-changing forms.",
            "Apply rate-limiting and CAPTCHA on login endpoints.",
            "Log all failed login attempts and alert on threshold breach.",
        ],
    },
    {
        "id": "VA-HTTP-003",
        "title": "Sensitive API Endpoint Probed",
        "description": (
            "The attacker probed API endpoints (/api/v1/config, /api/v1/sensors) "
            "that expose device configuration and network topology without authentication."
        ),
        "protocol": "HTTP",
        "trigger_actions": ["GET"],
        "trigger_paths": ["/api", "/config", "/.env", "/admin"],
        "cve_refs": ["CVE-2022-40684"],
        "cwe": ["CWE-285", "CWE-200"],
        "owasp_iot": ["IOT3", "IOT6"],
        "mitre": ["T0801", "T0861", "T1046"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="H", i="N", a="N"),
        "likelihood": "HIGH",
        "impact": "MEDIUM",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Require authentication (Bearer token / API key) on all /api/* endpoints.",
            "Implement role-based access control (RBAC) — read vs write separation.",
            "Return 401/403 rather than 404 for unauthorised API access.",
            "Apply API rate-limiting (e.g., 60 req/min per IP) using NGINX or gateway.",
        ],
    },

    # ── MQTT ───────────────────────────────────────────────────────────────
    {
        "id": "VA-MQTT-001",
        "title": "Unauthenticated MQTT Broker Connection",
        "description": (
            "The MQTT broker accepts connections without username/password. "
            "Any device on the network can publish or subscribe to all topics, "
            "enabling control-plane hijacking."
        ),
        "protocol": "MQTT",
        "trigger_actions": ["CONNECT"],
        "cve_refs": ["CVE-2023-3603"],
        "cwe": ["CWE-306", "CWE-862"],
        "owasp_iot": ["IOT2", "IOT9"],
        "mitre": ["T0848", "T0855", "T0869"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="C", c="H", i="H", a="H"),
        "likelihood": "HIGH",
        "impact": "CRITICAL",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Enable MQTT broker authentication (Mosquitto: password_file directive).",
            "Implement per-client ACL rules: restrict topic publish/subscribe by client ID.",
            "Enable TLS on port 8883; disable plaintext 1883 on public interfaces.",
            "Use MQTT 5.0 enhanced authentication for mutual TLS where supported.",
        ],
    },
    {
        "id": "VA-MQTT-002",
        "title": "MQTT Topic Enumeration / Wildcard Subscription",
        "description": (
            "The attacker subscribed using wildcard patterns (#, +/+) to enumerate "
            "all available topics and harvest telemetry data from the entire topic tree."
        ),
        "protocol": "MQTT",
        "trigger_actions": ["SUBSCRIBE"],
        "cve_refs": [],
        "cwe": ["CWE-200", "CWE-285"],
        "owasp_iot": ["IOT6", "IOT7"],
        "mitre": ["T0801", "T0811", "T0861"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="H", i="N", a="N"),
        "likelihood": "HIGH",
        "impact": "HIGH",
        "stage": "ANALYSIS",
        "remediation": [
            "Restrict wildcard subscriptions in broker ACL to authorised clients only.",
            "Implement topic namespacing with client-specific prefixes.",
            "Log wildcard subscription attempts and alert on anomalous patterns.",
            "Consider using a private/closed MQTT namespace hidden from public brokers.",
        ],
    },
    {
        "id": "VA-MQTT-003",
        "title": "Malicious MQTT Publish to Control Topic",
        "description": (
            "The attacker published to control topics (e.g., home/alarm/status, "
            "factory/plc/status), potentially issuing false commands to actuators "
            "or overriding safety-critical states."
        ),
        "protocol": "MQTT",
        "trigger_actions": ["PUBLISH"],
        "cve_refs": [],
        "cwe": ["CWE-284", "CWE-346"],
        "owasp_iot": ["IOT2", "IOT7"],
        "mitre": ["T0855", "T0848", "T0843"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="C", c="L", i="H", a="H"),
        "likelihood": "HIGH",
        "impact": "CRITICAL",
        "stage": "RISK_ASSESSMENT",
        "remediation": [
            "Enforce publish ACLs: only authorised device IDs may write to control topics.",
            "Implement message signing/HMAC to verify publisher authenticity.",
            "Use retained-message auditing to detect unauthorised state changes.",
            "Apply schema validation on MQTT payloads to reject malformed commands.",
        ],
    },

    # ── Modbus ─────────────────────────────────────────────────────────────
    {
        "id": "VA-MOD-001",
        "title": "Unauthenticated Modbus/TCP Read Access",
        "description": (
            "Modbus/TCP has no built-in authentication. An attacker can read all "
            "holding registers (sensor values, process states) without credentials, "
            "enabling industrial espionage and attack planning."
        ),
        "protocol": "MODBUS",
        "trigger_actions": ["READ_HOLDING_REGS", "READ_COILS", "READ_INPUT_REGS"],
        "cve_refs": ["CVE-2022-30267"],
        "cwe": ["CWE-306", "CWE-285"],
        "owasp_iot": ["IOT2", "IOT7"],
        "mitre": ["T0801", "T0861", "T0846"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="H", i="N", a="N"),
        "likelihood": "HIGH",
        "impact": "HIGH",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Deploy a Modbus-aware industrial firewall/proxy with whitelist rules.",
            "Restrict Modbus TCP port 502 to known engineering workstation IPs only.",
            "Implement VPN or TLS tunnel (Modbus over TLS, RFC 9202) for remote access.",
            "Use IDS signatures (Snort/Suricata Modbus preprocessor) for anomaly alerts.",
        ],
    },
    {
        "id": "VA-MOD-002",
        "title": "Unauthorised Modbus Write to Coil/Register",
        "description": (
            "The attacker issued a Write Single Coil or Write Register command, "
            "directly manipulating PLC/SCADA process variables. In an OT environment "
            "this can cause physical damage, safety incidents, or production disruption."
        ),
        "protocol": "MODBUS",
        "trigger_actions": ["WRITE_COIL", "WRITE_REGISTER", "WRITE_MULTI_REGS"],
        "cve_refs": ["CVE-2022-30267", "CVE-2021-32934"],
        "cwe": ["CWE-284", "CWE-749"],
        "owasp_iot": ["IOT2", "IOT8"],
        "mitre": ["T0855", "T0848", "T0800"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="C", c="L", i="H", a="H"),
        "likelihood": "MEDIUM",
        "impact": "CRITICAL",
        "stage": "RISK_ASSESSMENT",
        "remediation": [
            "Enforce read-only mode on Modbus for all non-engineering IPs (firewall ACL).",
            "Require operator confirmation for write commands (2-factor OT control).",
            "Log all write operations to tamper-proof SIEM with immediate alerting.",
            "Apply IEC 62443-3-3 SR 3.6: communication integrity for control systems.",
        ],
    },

    # ── CoAP ───────────────────────────────────────────────────────────────
    {
        "id": "VA-COAP-001",
        "title": "CoAP Resource Discovery Without Authentication",
        "description": (
            "The attacker issued CoAP GET /.well-known/core to enumerate all "
            "exposed resources. CoAP has no session layer — all resources are "
            "accessible to any UDP sender by default."
        ),
        "protocol": "COAP",
        "trigger_actions": ["GET", "DISCOVER"],
        "cve_refs": [],
        "cwe": ["CWE-306", "CWE-200"],
        "owasp_iot": ["IOT2", "IOT3"],
        "mitre": ["T1046", "T0861"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="M", i="N", a="N"),
        "likelihood": "HIGH",
        "impact": "MEDIUM",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Implement DTLS (RFC 7252 §9) for CoAP to provide transport security.",
            "Restrict /.well-known/core access to local subnet only via ACL.",
            "Use CoAP with OSCORE (RFC 8613) for end-to-end security on resource access.",
        ],
    },
    {
        "id": "VA-COAP-002",
        "title": "CoAP PUT/POST Resource Manipulation",
        "description": (
            "The attacker used CoAP PUT or POST to modify device resources "
            "(actuator states, configuration values). Without DTLS the integrity "
            "of these commands cannot be verified."
        ),
        "protocol": "COAP",
        "trigger_actions": ["PUT", "POST"],
        "cve_refs": [],
        "cwe": ["CWE-284", "CWE-346"],
        "owasp_iot": ["IOT2", "IOT7"],
        "mitre": ["T0855", "T0819"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="L", i="H", a="H"),
        "likelihood": "MEDIUM",
        "impact": "HIGH",
        "stage": "ANALYSIS",
        "remediation": [
            "Require DTLS PSK or certificate authentication before PUT/POST operations.",
            "Validate payload schema server-side; reject unexpected resource types.",
            "Implement resource versioning (ETag) with optimistic locking to prevent replay.",
        ],
    },

    # ── Cross-protocol / general ───────────────────────────────────────────
    {
        "id": "VA-GEN-001",
        "title": "Port Scan / Service Discovery",
        "description": (
            "Multiple connection attempts across different services from the same "
            "source IP within a short window indicate automated port scanning "
            "(Shodan, Masscan, nmap). The attacker is mapping the device attack surface."
        ),
        "protocol": "MULTI",
        "trigger_actions": ["CONNECT"],
        "trigger_multi_protocol": True,
        "cve_refs": [],
        "cwe": ["CWE-200"],
        "owasp_iot": ["IOT2", "IOT8"],
        "mitre": ["T1046", "T0846"],
        "cvss_vector": dict(av="N", ac="L", pr="N", ui="N", s="U", c="L", i="N", a="N"),
        "likelihood": "HIGH",
        "impact": "LOW",
        "stage": "IDENTIFICATION",
        "remediation": [
            "Disable all services not required for device function (attack surface reduction).",
            "Implement port-knocking or zero-trust network access for management ports.",
            "Deploy network IDS (Zeek/Snort) with scan-detection signatures.",
            "Report scanning IPs to threat-intel feeds; consider automated blocking.",
        ],
    },
    {
        "id": "VA-GEN-002",
        "title": "Anomalous Traffic Pattern (ML-Detected)",
        "description": (
            "The Isolation Forest anomaly detector flagged this event as statistically "
            "abnormal compared to the baseline traffic model. This may indicate "
            "novel exploit attempts, protocol fuzzing, or evasion techniques."
        ),
        "protocol": "ANY",
        "trigger_anomaly": True,
        "cve_refs": [],
        "cwe": ["CWE-693"],
        "owasp_iot": ["IOT2", "IOT5"],
        "mitre": ["T0820", "T1048"],
        "cvss_vector": dict(av="N", ac="H", pr="N", ui="N", s="U", c="L", i="L", a="L"),
        "likelihood": "MEDIUM",
        "impact": "MEDIUM",
        "stage": "ANALYSIS",
        "remediation": [
            "Investigate flagged packet captures for zero-day exploit patterns.",
            "Update Isolation Forest training data; lower contamination threshold if FP rate is high.",
            "Feed anomalous payloads to dynamic analysis sandbox for malware identification.",
            "Correlate with threat-intel IOC feeds (MISP, OTX) for known attack fingerprints.",
        ],
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# Risk Matrix  (Likelihood × Impact → Risk Level)
# Based on NIST SP 800-30 Table I-2
# ─────────────────────────────────────────────────────────────────────────────

RISK_MATRIX = {
    ("HIGH",   "CRITICAL"): ("CRITICAL", 10),
    ("HIGH",   "HIGH"):     ("HIGH",      8),
    ("HIGH",   "MEDIUM"):   ("HIGH",      7),
    ("HIGH",   "LOW"):      ("MEDIUM",    4),
    ("MEDIUM", "CRITICAL"): ("HIGH",      8),
    ("MEDIUM", "HIGH"):     ("HIGH",      7),
    ("MEDIUM", "MEDIUM"):   ("MEDIUM",    5),
    ("MEDIUM", "LOW"):      ("LOW",       2),
    ("LOW",    "CRITICAL"): ("MEDIUM",    5),
    ("LOW",    "HIGH"):     ("MEDIUM",    4),
    ("LOW",    "MEDIUM"):   ("LOW",       2),
    ("LOW",    "LOW"):      ("LOW",       1),
}

LIFECYCLE_STAGES = [
    "IDENTIFICATION",
    "ANALYSIS",
    "RISK_ASSESSMENT",
    "REMEDIATION",
    "REPORTING",
]


# ─────────────────────────────────────────────────────────────────────────────
# Assessment Engine
# ─────────────────────────────────────────────────────────────────────────────

_VA_DB_LOCK = threading.Lock()


def _get_va_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_va_db():
    """Create VA findings table alongside the honeypot event tables."""
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS va_findings (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp     TEXT NOT NULL,
                vuln_id       TEXT NOT NULL,
                title         TEXT,
                protocol      TEXT,
                src_ip        TEXT,
                cvss_score    REAL,
                cvss_severity TEXT,
                risk_level    TEXT,
                risk_score    INTEGER,
                lifecycle_stage TEXT,
                owasp_iot     TEXT,
                mitre_tech    TEXT,
                cwe           TEXT,
                cve_refs      TEXT,
                likelihood    TEXT,
                impact        TEXT,
                remediation   TEXT,
                evidence      TEXT,
                event_ids     TEXT
            );

            CREATE TABLE IF NOT EXISTS va_summary (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                generated_at  TEXT NOT NULL,
                total_findings INTEGER,
                critical_count INTEGER,
                high_count     INTEGER,
                medium_count   INTEGER,
                low_count      INTEGER,
                unique_ips     INTEGER,
                protocols_hit  TEXT,
                overall_risk   TEXT,
                summary_json   TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_va_findings_proto
                ON va_findings(protocol);
            CREATE INDEX IF NOT EXISTS idx_va_findings_severity
                ON va_findings(cvss_severity);
            CREATE INDEX IF NOT EXISTS idx_va_findings_ts
                ON va_findings(timestamp);
        """)
        conn.commit()
        conn.close()
    logger.info("VA database tables initialised.")


def _save_finding(finding: Dict[str, Any]):
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        conn.execute("""
            INSERT OR REPLACE INTO va_findings
            (timestamp, vuln_id, title, protocol, src_ip,
             cvss_score, cvss_severity, risk_level, risk_score,
             lifecycle_stage, owasp_iot, mitre_tech, cwe, cve_refs,
             likelihood, impact, remediation, evidence, event_ids)
            VALUES
            (:timestamp, :vuln_id, :title, :protocol, :src_ip,
             :cvss_score, :cvss_severity, :risk_level, :risk_score,
             :lifecycle_stage, :owasp_iot, :mitre_tech, :cwe, :cve_refs,
             :likelihood, :impact, :remediation, :evidence, :event_ids)
        """, {
            "timestamp":       finding["timestamp"],
            "vuln_id":         finding["vuln_id"],
            "title":           finding["title"],
            "protocol":        finding["protocol"],
            "src_ip":          finding["src_ip"],
            "cvss_score":      finding["cvss_score"],
            "cvss_severity":   finding["cvss_severity"],
            "risk_level":      finding["risk_level"],
            "risk_score":      finding["risk_score"],
            "lifecycle_stage": finding["lifecycle_stage"],
            "owasp_iot":       json.dumps(finding["owasp_iot"]),
            "mitre_tech":      json.dumps(finding["mitre_tech"]),
            "cwe":             json.dumps(finding["cwe"]),
            "cve_refs":        json.dumps(finding["cve_refs"]),
            "likelihood":      finding["likelihood"],
            "impact":          finding["impact"],
            "remediation":     json.dumps(finding["remediation"]),
            "evidence":        json.dumps(finding.get("evidence", {})),
            "event_ids":       json.dumps(finding.get("event_ids", [])),
        })
        conn.commit()
        conn.close()


def assess_event(event: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Given a honeypot event dict, return a list of VA findings triggered by it.
    Each finding covers all 5 lifecycle stages.
    """
    findings = []
    proto = event.get("protocol", "UNKNOWN").upper()
    action = event.get("action", "")
    src_ip = event.get("src_ip", "")
    is_anomaly = event.get("is_anomaly", False)

    for vuln in VULN_CATALOGUE:
        triggered = False

        # Multi-protocol scan check
        if vuln.get("trigger_multi_protocol"):
            triggered = _check_multi_protocol_scan(src_ip)
        # Anomaly-based trigger
        elif vuln.get("trigger_anomaly") and is_anomaly:
            triggered = True
        # Protocol + action match
        elif vuln.get("protocol") in (proto, "ANY", "MULTI"):
            if action in vuln.get("trigger_actions", []):
                # Optional threshold check
                if "trigger_threshold" in vuln:
                    count = _count_recent_actions(src_ip, proto, action, minutes=10)
                    triggered = count >= vuln["trigger_threshold"]
                # Optional path check for HTTP
                elif "trigger_paths" in vuln:
                    payload = event.get("payload", "")
                    triggered = any(p in payload for p in vuln["trigger_paths"])
                else:
                    triggered = True

        if not triggered:
            continue

        # ── Compute CVSS ──────────────────────────────────────────────────
        score, severity = cvss_score(**vuln["cvss_vector"])

        # ── Risk matrix ───────────────────────────────────────────────────
        risk_key = (vuln["likelihood"], vuln["impact"])
        risk_level, risk_score = RISK_MATRIX.get(risk_key, ("MEDIUM", 5))

        # ── OWASP labels ──────────────────────────────────────────────────
        owasp_labels = [
            f"{code}: {OWASP_IOT_TOP10[code]}"
            for code in vuln["owasp_iot"]
            if code in OWASP_IOT_TOP10
        ]

        # ── MITRE labels ──────────────────────────────────────────────────
        mitre_labels = [
            f"{tid}: {MITRE_TECHNIQUES.get(tid, 'Unknown')}"
            for tid in vuln["mitre"]
        ]

        finding = {
            "timestamp":       datetime.utcnow().isoformat(),
            "vuln_id":         vuln["id"],
            "title":           vuln["title"],
            "description":     vuln["description"],
            "protocol":        proto,
            "src_ip":          src_ip,
            "cvss_score":      score,
            "cvss_severity":   severity,
            "cvss_vector":     vuln["cvss_vector"],
            "risk_level":      risk_level,
            "risk_score":      risk_score,
            "lifecycle_stage": vuln["stage"],
            "lifecycle_path":  LIFECYCLE_STAGES,
            "owasp_iot":       owasp_labels,
            "mitre_tech":      mitre_labels,
            "cwe":             vuln["cwe"],
            "cve_refs":        vuln["cve_refs"],
            "likelihood":      vuln["likelihood"],
            "impact":          vuln["impact"],
            "remediation":     vuln["remediation"],
            "evidence":        {
                "event_id":   event.get("id"),
                "action":     action,
                "payload":    event.get("payload", "")[:200],
                "country":    event.get("country", ""),
                "city":       event.get("city", ""),
                "anomaly_score": event.get("anomaly_score", 0.0),
            },
        }

        _save_finding(finding)
        findings.append(finding)
        logger.info("[VA] %s triggered %s (CVSS %.1f %s)",
                    src_ip, vuln["id"], score, severity)

    return findings


def _count_recent_actions(ip: str, protocol: str,
                           action: str, minutes: int = 10) -> int:
    cutoff = (datetime.utcnow() - timedelta(minutes=minutes)).isoformat()
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        row = conn.execute(
            "SELECT COUNT(*) FROM events "
            "WHERE src_ip=? AND protocol=? AND action=? AND timestamp>=?",
            (ip, protocol, action, cutoff)
        ).fetchone()
        conn.close()
    return row[0] if row else 0


def _check_multi_protocol_scan(ip: str, minutes: int = 5) -> bool:
    """True if the same IP hit ≥3 different protocols in the window."""
    cutoff = (datetime.utcnow() - timedelta(minutes=minutes)).isoformat()
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        row = conn.execute(
            "SELECT COUNT(DISTINCT protocol) FROM events "
            "WHERE src_ip=? AND timestamp>=?",
            (ip, cutoff)
        ).fetchone()
        conn.close()
    return (row[0] if row else 0) >= 3


def get_va_findings(limit: int = 200,
                     severity: str = None,
                     protocol: str = None) -> List[Dict[str, Any]]:
    """Retrieve stored VA findings, optionally filtered."""
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        q = "SELECT * FROM va_findings WHERE 1=1"
        params: list = []
        if severity:
            q += " AND cvss_severity = ?"
            params.append(severity.upper())
        if protocol:
            q += " AND protocol = ?"
            params.append(protocol.upper())
        q += " ORDER BY cvss_score DESC, id DESC LIMIT ?"
        params.append(limit)
        rows = [dict(r) for r in conn.execute(q, params).fetchall()]
        conn.close()

    # Deserialise JSON columns
    for r in rows:
        for col in ("owasp_iot", "mitre_tech", "cwe", "cve_refs",
                    "remediation", "evidence", "event_ids"):
            try:
                r[col] = json.loads(r[col]) if r[col] else []
            except Exception:
                pass
    return rows


def generate_va_summary() -> Dict[str, Any]:
    """Generate and persist an executive VA summary."""
    findings = get_va_findings(limit=10_000)

    by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "NONE": 0}
    by_protocol: Dict[str, int] = {}
    unique_ips: set = set()
    owasp_hits: Dict[str, int] = {}
    mitre_hits: Dict[str, int] = {}

    for f in findings:
        sev = f.get("cvss_severity", "NONE")
        by_severity[sev] = by_severity.get(sev, 0) + 1
        proto = f.get("protocol", "UNKNOWN")
        by_protocol[proto] = by_protocol.get(proto, 0) + 1
        if f.get("src_ip"):
            unique_ips.add(f["src_ip"])
        for o in (f.get("owasp_iot") or []):
            key = o.split(":")[0].strip()
            owasp_hits[key] = owasp_hits.get(key, 0) + 1
        for m in (f.get("mitre_tech") or []):
            key = m.split(":")[0].strip()
            mitre_hits[key] = mitre_hits.get(key, 0) + 1

    # Overall risk = worst severity seen
    overall = "LOW"
    for level in ("CRITICAL", "HIGH", "MEDIUM"):
        if by_severity.get(level, 0) > 0:
            overall = level
            break

    summary = {
        "generated_at":    datetime.utcnow().isoformat(),
        "total_findings":  len(findings),
        "by_severity":     by_severity,
        "by_protocol":     by_protocol,
        "unique_ips":      len(unique_ips),
        "overall_risk":    overall,
        "top_owasp":       sorted(owasp_hits.items(), key=lambda x: -x[1])[:5],
        "top_mitre":       sorted(mitre_hits.items(), key=lambda x: -x[1])[:5],
        "lifecycle_coverage": LIFECYCLE_STAGES,
    }

    # Persist
    with _VA_DB_LOCK:
        conn = _get_va_conn()
        conn.execute("""
            INSERT INTO va_summary
            (generated_at, total_findings, critical_count, high_count,
             medium_count, low_count, unique_ips, protocols_hit,
             overall_risk, summary_json)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (
            summary["generated_at"],
            summary["total_findings"],
            by_severity.get("CRITICAL", 0),
            by_severity.get("HIGH", 0),
            by_severity.get("MEDIUM", 0),
            by_severity.get("LOW", 0),
            len(unique_ips),
            json.dumps(by_protocol),
            overall,
            json.dumps(summary),
        ))
        conn.commit()
        conn.close()

    return summary


# ─────────────────────────────────────────────────────────────────────────────
# Event bus subscriber — wires VA engine into the live pipeline
# ─────────────────────────────────────────────────────────────────────────────

def on_event(event: Dict[str, Any]):
    """Subscribe this to the honeypot event bus."""
    try:
        assess_event(event)
    except Exception as e:
        logger.error("VA assessment error: %s", e)
