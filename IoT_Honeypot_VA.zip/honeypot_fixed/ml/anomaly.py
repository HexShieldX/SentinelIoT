"""
ml/anomaly.py
=============
AI-based anomaly detection using scikit-learn's Isolation Forest.
Runs as a background thread, subscribes to the event bus,
featurises each event and flags anomalies in real time.
Periodically retrains on accumulated data.
"""
import threading
import time
import logging
import sqlite3
import json
from typing import Dict, Any, List, Optional
from datetime import datetime

import numpy as np

try:
    from sklearn.ensemble import IsolationForest
    from sklearn.preprocessing import LabelEncoder
    _ML_AVAILABLE = True
except ImportError:
    _ML_AVAILABLE = False
    logging.getLogger("honeypot").warning(
        "scikit-learn not installed — anomaly detection disabled. "
        "Run: pip install scikit-learn"
    )

from config.settings import (
    ANOMALY_THRESHOLD, ANOMALY_RETRAIN_EVERY, ANOMALY_MIN_SAMPLES, DB_PATH
)

logger = logging.getLogger("honeypot.ml")

# Protocol → integer mapping (stable across restarts)
PROTOCOL_MAP = {
    "MQTT": 0, "TELNET": 1, "SSH": 2,
    "HTTP": 3, "MODBUS": 4, "COAP": 5, "UNKNOWN": 6
}
ACTION_KEYWORDS = [
    "connect", "login", "auth", "publish", "subscribe", "read",
    "write", "scan", "brute", "command", "error", "disconnect"
]


def _featurise(event: Dict[str, Any]) -> List[float]:
    """
    Convert a raw event dict into a fixed-length numeric feature vector.
    Features:
      0  protocol_id        (int 0-6)
      1  src_port           (int, normalised /65535)
      2  payload_len        (int, log-normalised)
      3  hour_of_day        (int 0-23)
      4  action_keyword_hit (int 0-1 per keyword, 12 features)
      => total: 16 features
    """
    proto = event.get("protocol", "UNKNOWN").upper()
    proto_id = PROTOCOL_MAP.get(proto, 6)

    src_port = float(event.get("src_port") or 0) / 65535.0

    payload = str(event.get("payload") or "")
    payload_len = float(np.log1p(len(payload)))

    ts = event.get("timestamp", datetime.utcnow().isoformat())
    try:
        hour = datetime.fromisoformat(ts).hour
    except Exception:
        hour = 0
    hour_norm = hour / 23.0

    payload_lower = payload.lower()
    action_lower  = str(event.get("action") or "").lower()
    combined = payload_lower + " " + action_lower
    keyword_hits = [1.0 if kw in combined else 0.0 for kw in ACTION_KEYWORDS]

    return [float(proto_id), src_port, payload_len, hour_norm] + keyword_hits


class AnomalyDetector:
    """
    Isolation Forest wrapper that:
    - Collects events into a buffer
    - Retrains every ANOMALY_RETRAIN_EVERY events (once min samples reached)
    - Scores each incoming event in real time
    - Updates the DB row with is_anomaly / anomaly_score
    """

    def __init__(self):
        self._model: Optional[IsolationForest] = None
        self._lock = threading.Lock()
        self._event_count = 0
        self._buffer: List[List[float]] = []
        self._enabled = _ML_AVAILABLE

        if self._enabled:
            # Attempt to warm up from existing DB data on startup
            threading.Thread(target=self._warmup, daemon=True).start()

    # ── Public API ────────────────────────────────────────────────────────

    def score(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Score an event. Returns the event dict enriched with
        'is_anomaly' (bool) and 'anomaly_score' (float).
        NOTE: buffering for retraining is handled in on_event(), not here.
        """
        if not self._enabled:
            event["is_anomaly"] = False
            event["anomaly_score"] = 0.0
            return event

        features = _featurise(event)
        score_val = 0.0
        is_anomaly = False

        if self._model is not None:
            try:
                arr = np.array([features])
                score_val = float(self._model.score_samples(arr)[0])
                is_anomaly = score_val < ANOMALY_THRESHOLD
            except Exception as e:
                logger.debug("Scoring error: %s", e)

        event["is_anomaly"]    = is_anomaly
        event["anomaly_score"] = round(score_val, 4)

        if is_anomaly:
            logger.warning(
                "[ANOMALY] score=%.4f proto=%s ip=%s action=%s",
                score_val, event.get("protocol"), event.get("src_ip"), event.get("action")
            )

        return event

        return event

    # ── Training ──────────────────────────────────────────────────────────

    def _retrain(self):
        with self._lock:
            data = list(self._buffer)

        if len(data) < ANOMALY_MIN_SAMPLES:
            return

        logger.info("Retraining Isolation Forest on %d samples …", len(data))
        try:
            X = np.array(data)
            model = IsolationForest(
                n_estimators=150,
                contamination=0.05,   # expect ~5% anomalies
                random_state=42,
                n_jobs=-1
            )
            model.fit(X)
            with self._lock:
                self._model = model
            logger.info("Isolation Forest retrained — ready.")
        except Exception as e:
            logger.error("Retrain failed: %s", e)

    def _warmup(self):
        """Load historical events from DB to pre-train the model."""
        time.sleep(3)  # let DB init finish
        try:
            conn = sqlite3.connect(DB_PATH)
            rows = conn.execute(
                "SELECT protocol, src_port, payload, timestamp, action "
                "FROM events ORDER BY id DESC LIMIT 5000"
            ).fetchall()
            conn.close()
        except Exception:
            return

        if not rows:
            logger.info("No historical data for ML warmup.")
            return

        features = []
        for r in rows:
            ev = {
                "protocol":  r[0],
                "src_port":  r[1],
                "payload":   r[2],
                "timestamp": r[3],
                "action":    r[4],
            }
            features.append(_featurise(ev))

        with self._lock:
            self._buffer = features

        self._retrain()

    # ── Event bus subscriber callback ─────────────────────────────────────

    def on_event(self, event: Dict[str, Any]):
        """Called by the event bus for every new event.
        Scoring is now done in bus.publish() before DB insert.
        Here we only buffer the features for periodic retraining.
        """
        if not self._enabled:
            return
        features = _featurise(event)
        with self._lock:
            self._buffer.append(features)
            self._event_count += 1
            should_retrain = (
                len(self._buffer) >= ANOMALY_MIN_SAMPLES and
                self._event_count % ANOMALY_RETRAIN_EVERY == 0
            )
        if should_retrain:
            threading.Thread(target=self._retrain, daemon=True).start()


    def _update_db(self, event: Dict[str, Any]):
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.execute(
                "UPDATE events SET is_anomaly=?, anomaly_score=? WHERE id=?",
                (int(event["is_anomaly"]), event["anomaly_score"], event["id"])
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.debug("DB update for anomaly score failed: %s", e)


# Singleton
detector = AnomalyDetector()
